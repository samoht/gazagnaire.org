(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

type 'a t =
    { states : int list;
      transitions : (int * 'a * int) list;
      start : int;
      final : int }
      
let map f a =
  { a with transitions = List.map (function (b,c,d) -> (b,f c,d)) a.transitions }

let fresh () = Std.unique ()
    
let empty () =
  let n = fresh () in
    { states = [n];
      transitions = [];
      start = n;
      final = n; }

let is_empty a =
  a.transitions = []
    
let singleton l = 
  let start = fresh () in
  let final = fresh () in
    { states = [ start; final ];
      transitions = [ start, l, final ];
      start = start;
      final = final; }

let posptend a l =
  let final = fresh () in
    { states = final :: a.states;
      transitions = (a.final, l, final) :: a.transitions;
      final = final;
      start = a.start }

let replace a x y  =
  let aux a = 
    if a = x then y else a
  in
    { states = List.map aux a.states;
      transitions = List.map (function (a,t,b) -> aux a,t,aux b) a.transitions;
      start = aux a.start;
      final = aux a.final }
	
(* remplace les etats x par y dans l'ensemble des transitions *)
let replace_transition x y t =
  let aux a = 
    if a = x then y else a
  in
    List.map (function (a,t,b) -> aux a,t,aux b) t
      
let remove_state x s =
  List.filter ((<>) x) s

let concat a b =
    if is_empty a
    then b
    else if is_empty b
    then a
    else 
      { states = (remove_state a.final a.states) @ b.states;
	transitions = replace_transition a.final b.start a.transitions @ b.transitions;
	start = a.start;
	final = b.final; }

let check a =
  assert (List.fold_left (fun accu (a,_,b) -> accu && a <> b) true a.transitions);
  a
      

    
let transition_to_dot action_to_string (s1,t,s2) =
    Printf.sprintf "%i -> %i [label=\"%s\"];\n" s1 s2 (action_to_string t)

open Base_types

type 'a automaton = 'a t
module type Sig = 
sig
  type label
  type t
  (*val singleton : action -> t *)
  val from_trace : trace -> label
  val combine_action : t -> action -> t
  val from_automaton : label automaton -> t
  val to_automaton : t -> label automaton
  val string_of_transition : int * label * int -> string
end


module Model (M : Sig) : Model with type t = M.t and type env = Environment.t =
struct
  type env = Environment.t

  type t = M.t

  let empty () = M.from_automaton (empty ())

  let combine_action = M.combine_action

  let combine a b = 
    M.from_automaton (check (concat (M.to_automaton a) (M.to_automaton b)))

  let from_trace_list l =
    List.fold_left (fun accu a -> M.combine_action accu (a:>action)) (empty ()) l

  let combine_if_aux env decode a b then_model else_model =
    let case_b = from_trace_list (decode (`Trace(a, `Case b)))
    and case_not_b = from_trace_list (decode (`Trace(a, `Case (Not b))))
    in
      (* on a deux branches dont on va fusionner les extremites *)
    let then_model = concat (M.to_automaton case_b) then_model
    and else_model = concat (M.to_automaton case_not_b) else_model
    in
      check 
	{ states = 
	    then_model.states 
	    @ remove_state else_model.final (remove_state else_model.start else_model.states);
	  transitions = 
	    then_model.transitions 
	    @ replace_transition else_model.start then_model.start 
	    (replace_transition else_model.final then_model.final else_model.transitions);
	  start = then_model.start;
	  final = then_model.final }

  let combine_if env decode a b then_model else_model = 
    M.from_automaton (combine_if_aux env decode a b (M.to_automaton then_model) (M.to_automaton else_model))

  


  let combine_while_aux env decode a b while_model =
    let case_b = from_trace_list (decode (`Trace(a, `Case b)))
    and case_not_b = from_trace_list (decode (`Trace(a, `Case (Not b))))
    in
    let while_model = concat (M.to_automaton case_b) while_model
    and exit_model = M.to_automaton case_not_b
    in
      check 
	{ states =  
	    remove_state exit_model.start exit_model.states 
	    @ remove_state while_model.final while_model.states;
	  transitions = 
	    replace_transition exit_model.start while_model.start exit_model.transitions
	    @ replace_transition while_model.final while_model.start while_model.transitions;
	  start = while_model.start;
	  final = exit_model.final }
	
  let combine_while env decode a b while_model =
    M.from_automaton (combine_while_aux env decode a b (M.to_automaton while_model))


	
  let combine_call_aux env decode (p:string) (names:(loc * arg list) list) args call_model =
    (* if agents = [] 
       then call_model
       else *)
      let instr_list = Trace.combine_names_args env decode names args in
(*      let lsave_list = List.map (function i -> `Trace(i, `Save)) agents in *)
(*      let return = M.to_automaton (from_trace_list (List.map (function i -> `Trace(i, `Return)) agents)) in *)
(*      let save = M.to_automaton (from_trace_list (lsave_list @ instr_list)) in *)
      let instr = M.to_automaton (from_trace_list instr_list) in
     	check (concat instr call_model)

	  (*{ states = remove_state save.final (remove_state return.start (save.states @ call_model.states @ return.states ));
	    transitions = 
	    replace_transition save.final call_model.start 
	    (replace_transition return.start call_model.final 
	    (save.transitions @ call_model.transitions @ return.transitions));
	    start = save.start;
	    final = return.final } *)

  let combine_call p names args agents groups call_model =
    M.from_automaton (combine_call_aux p names args agents groups (M.to_automaton call_model))



  let state_to_dot is_final s =
    Printf.sprintf "node[shape=\"%s\" width=1 height=1 label=\"\"]; %i;\n" (if is_final s then "doublecircle" else "circle") s
          
  let start_to_dot s =
    Printf.sprintf "node[shape=none label=\"\"] start;\nstart -> %i;\n" s
      
  let font = Tools.font
    
  let to_string_aux a = 
    "digraph {\n"
    ^"graph [fontname=\""^font^"\"];\n"
    ^"node [fontname=\""^font^"\"];\n"
    ^"edge [fontname=\""^font^"\"];\n"
    ^List.fold_left (fun accu s -> accu ^ state_to_dot ((=) a.final) s) "" a.states
    ^start_to_dot a.start
    ^List.fold_left (fun accu t -> accu ^ M.string_of_transition t) "" a.transitions
    ^"}"

  let to_string a = 
    to_string_aux (M.to_automaton a) 



  let fresh () = 
    "temp" ^ string_of_int (Std.unique ())
      
  let output_model file (a:t) =
    if file = "" 
    then () (*dessine tous les pomsets donc c'est relou: output_string stdout (to_string a)*)
    else let name = fresh () in
    let f = open_out (Tools.trash_dir^name^".dot") in
      Tools.debug_endline ("Creating "^file);
      output_string f (to_string a); 
      close_out f;
      Tools.execute (Tools.dot_path^"dot "^Tools.trash_dir^name^".dot -T"^Tools.draw^" -o "^file)
end
      
type 'a exec = 
    { current_state : int;
      automaton : 'a t;
      agent_names : string list }
      
let has_undefined_agents a =  a.agent_names <> []

let declare_agent a = `Start a.agent_names, { a with agent_names = [] }
 
let map_exec f e =
  {e  with automaton = map f e.automaton }

let rec remove_doublon accu = function
  | [] -> List.rev accu
  | h :: t -> remove_doublon (h::accu) (List.filter ((<>) h) t)

let make_exec agents_of a =
  { current_state = a.start;
    automaton = a;
    agent_names = remove_doublon [] (List.fold_left (fun accu (_,t,_) -> agents_of t @ accu)[] a.transitions) } 

let is_finished code =
  code.current_state = code.automaton.final

let fireable condition code =
  List.filter (function (s,l,_) -> s = code.current_state && condition l) code.automaton.transitions
