(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

module type T =
sig
  type t
  val classe : Bmsc.label -> t
  val create : t -> Bmsc.label
end

module Make (Arg : T) =
struct

  type t = 
      { letter_int : (Arg.t, int) Hashtbl.t;
	int_letter : (int, Arg.t) Hashtbl.t; }

  let create () =
    { letter_int = Hashtbl.create 99;
      int_letter = Hashtbl.create 99; }
    
  let classe c l =
    if Hashtbl.mem c.letter_int (Arg.classe (Box.label l))
    then Hashtbl.find c.letter_int (Arg.classe (Box.label l))
    else raise (Invalid_argument "Classes.Sigma.classe")
      
  let dummy c i =
    if Hashtbl.mem c.int_letter i
    then Box.create (Arg.create (Hashtbl.find c.int_letter i))
    else raise (Invalid_argument "Classes.Sigma.dummy")

  let to_list c = 
    Array.to_list (Array.init (Hashtbl.length c.letter_int) (dummy c))

  let size c = Hashtbl.length c.letter_int

  let iter f c =
    Hashtbl.iter f c.letter_int 

  let update c a = 
    let classe = ref (size c) in
      Pomset.G.iter_vertex (function l -> 
			      if not (Hashtbl.mem c.letter_int (Arg.classe (Box.label l))) 
			      then begin
				Hashtbl.add c.letter_int (Arg.classe (Box.label l)) !classe;
				Hashtbl.add c.int_letter !classe (Arg.classe (Box.label l));
				incr classe 
			      end) a

  let classes a =
    let c = create () in
      update c a;
      c

  let subset a b =
    Hashtbl.fold (fun k l accu -> accu && Hashtbl.mem b.letter_int k) a.letter_int true

  let equal a b =
    subset a b && size a = size b
end

module Instance =
struct
  open Base_types

  type t = string
  let classe (l:Bmsc.label) = Bmsc.instance l
  let create i = (`Trace(i, `Read ""):Bmsc.label)
end

module Sigma =
struct
  type t = Bmsc.label
  let classe l = l
  let create l = l
end

module I = Make(Instance)
module S = Make(Sigma)

(* on choisit ici le type de classe *)
include I
