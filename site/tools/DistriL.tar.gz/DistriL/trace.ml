open Base_types

(* attention les args sont les noms x@address *)
let combine_names_args env (decode:action -> action list) names args =
  let agent_args,var_args = List.split args in
  let agent_names,var_names = List.split names in
  let aux a = function
    | Func f, Var v -> decode (`Instr (Agent a, `Create_func (f,v)))
    | Int x, e -> decode (`Instr (Agent a, `Create_int (x,e)))
    | _,_ -> failwith "Trace.combine_names_args"
  in
  let aux2 (a,(xl,el)) = match a with 
    | Agent a -> 
	List.flatten (List.map (aux (Environment.get_loc env a)) (List.combine xl el))
    | Group g -> 
	List.flatten (List.flatten (List.map (fun a -> List.map (aux a) (List.combine xl el)) (Environment.agents_of_group env g(*Environment.get_loc env g*))))
    | Global -> List.flatten (List.flatten (List.map (fun a -> List.map (aux a) (List.combine xl el)) (Environment.agent_names env)))
  in
    List.flatten (List.map aux2 (List.combine agent_args (List.combine var_names var_args))) 
    

module type Sig =
sig 
  type t
  val empty : unit -> t
  val is_empty : t -> bool
  val combine_action : t -> action -> t
  val combine : t -> t -> t
  val to_string : t -> string
  val output_model : string -> t -> unit
end

module Model (M : Sig) : Model with type t = M.t and type env = Environment.t =
struct
  type env = Environment.t
  type t = M.t
  let empty = M.empty
  let combine_action = M.combine_action
  let combine = M.combine

  let prepend a m = 
    M.combine (M.combine_action (empty ()) a) m

  let from_trace_list l = 
    List.fold_left (fun accu a -> M.combine_action accu (a:>action))  (empty ()) l
	  
  let combine_if env decode a b then_model else_model =
    let case_b = from_trace_list (decode (`Trace(a, `Case b)))
    and case_not_b = from_trace_list (decode (`Trace(a, `Case (Not b))))
    in
      if M.is_empty then_model
      then M.combine case_not_b else_model
      else if M.is_empty else_model
      then M.combine case_b then_model
      else invalid_arg "Trace.combine_if" 
    
  let combine_while env decode a b model =
    let case_b = from_trace_list (decode (`Trace(a, `Case b)))
    and case_not_b = from_trace_list (decode (`Trace(a, `Case (Not b))))
    in
      if M.is_empty model
      then case_not_b
      else M.combine case_b model

  (* todo : n'empiler que les processes qui apparaissent dans model ... *)
  let combine_call env decode p names args model =
    let instr_list = combine_names_args env decode names args in
(*    let lsave_list = List.map (function i -> `Trace(i, `Save)) agents in *)
(*    let return = from_trace_list (List.map (function i -> `Trace(i, `Return)) agents) in *)
  (*  let save = from_trace_list ( lsave_list @ instr_list ) in *)
      (*M.combine (M.combine save model) return *)
      M.combine (from_trace_list instr_list) model

  let to_string = M.to_string

  let output_model file m = 
    if file = ""
    then output_string stdout (to_string m)
    else M.output_model file m
end
