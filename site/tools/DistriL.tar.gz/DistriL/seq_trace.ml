(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

(* Un modele de calcul qui genere un langage de trace. 
  Les calls sont deplies et sont donc remplaces par un
   Save afin de  gerer correctement le contexte *)
open Base_types

module Model = Trace.Model(
  struct 
    type t = trace_io list

    let empty () = []

    let is_empty l = l = []
  
    let to_string l = action_list (List.map (fun x -> (x:>action)) l)
    
    let combine_action (l:t) (e:action) = 
      (*Printf.eprintf "%s @ %s\n" (to_string l) (action e);*)
      let e = to_trace_io e in
	if l = [] && e = `Nope 
	then []
	else if e = `Nope 
	then l
	else l @ [e]

    let rec combine m1 m2 =
      (*Printf.eprintf "%s @ %s\n" (to_string m1) (to_string m2);*)
      match m1,m2 with
      | [],[] -> []
      | [],_ -> m2
      | _,[] -> m1
      |_,_ -> m1 @ m2

    let output_model file m = 
      if file = "" 
      then Printf.printf "TRACE :\n%s\n" (to_string m)
      else 
	let f = open_out file in
	  Tools.debug_endline ("Creating "^file);
	  output_string f (to_string m); 
	  close_out f;
  end)

