(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Base_types

module type Sig =
sig
  val num_expr : (string -> int) -> (string -> int list -> int) -> Base_types.num_expr -> int
  val bool_expr : (string -> int) -> (string -> int list -> int) -> Base_types.bool_expr -> bool
  val print :string -> int -> unit
  val read : string -> string -> int 
  val check_consistency : bool
end

let num_op = function
  | Add -> ( + )
  | Soustract -> ( - )
  | Product -> ( * )
  | Divide -> ( / )
      
let rec num_expr var func = function
  | Num i -> i
  | Var x -> var x
  | Inv e -> - (num_expr var func e)
  | Num_op (e, op, f) -> (num_op op) (num_expr var func e) (num_expr var func f)
  | Apply (f, el) -> (func f) (List.map (num_expr var func) el)
      
let bool_op = function
  | Le -> ( < )
  | Leq -> ( <= )
  | Ge -> ( > )
  | Geq -> ( >= )
  | Eq -> ( = )
  | Neq -> ( <> )
      
let rec bool_expr var func = function
  | True -> true
  | False -> false
  | Bool_op (e, op, f) -> (bool_op op) (num_expr var func e) (num_expr var func f)
  | Not b -> not (bool_expr var func b)
  | And (b,c) -> bool_expr var func b && bool_expr var func c
  | Or (b,c) -> bool_expr var func b || bool_expr var func c 



(**** evaluation ****)
(* parcours tout le programme *)
module Always_true =
struct
  let num_expr var func e = 0
  let bool_expr var func b = true
  let check_consistency = true
  let print a n = ()
  let read a x = 0
end


(* execute le programme normalement *)
module Normal =
struct
  let num_expr = num_expr

  let bool_expr = bool_expr
 
  let print a n =
    Printf.printf "[%s] ---> %i\n" a n;
    flush stdout
(*    `Io (a, `Output n) *)
      
  let read a x =
    Printf.printf "[%s] <--- %s =? " a x;
    let n = read_int () in
      n (*, `Io (a, `Input (x, n))*)

  let check_consistency = false
end




