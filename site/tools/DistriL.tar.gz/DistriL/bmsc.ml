(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

(* la partie commune a tous les 
pomsets 
*)
open Base_types

type label = trace_io

let from_string s = 
  let l = Parser.trace_io Lexer.main (Lexing.from_string s) in
    (l:>label)
 
let instance (m:label) = agent_of_action (m:>action)
 
let message_name (m:label) = match m with
  | `Trace(a, `Send (b,m,_)) -> Printf.sprintf "%s -%s-> %s" a m b
  | `Trace(a, `Recv (b,m,_)) -> Printf.sprintf "%s -%s-> %s" b m a
  | _ -> invalid_arg "message_name"

let is_send = function 
  | `Trace (_, `Send _) -> true
  | _ -> false
      
let is_recv = function
  | `Trace (_, `Recv _) -> true
  | _ -> false
      
let is_intl m = not ( is_send m || is_recv m )

let same_message l1 l2 = 
  is_send l1 && is_recv l2 &&  message_name l1 = message_name l2

let to_string (l:label) = action (l :> action) 

let pp (e:label) = no_loc_action (e:>action)
 


  
