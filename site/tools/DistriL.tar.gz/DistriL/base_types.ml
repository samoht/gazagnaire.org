(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

type num_op = Add | Soustract | 
Product 
| 
Divide
	  
type num_expr =
  | Num of int
  | Var of string
  | Inv of num_expr
  | Num_op of num_expr * num_op * num_expr
  | Apply of string * num_expr list
      
type bool_op = Le | Leq | Ge | Geq | Eq | Neq
	
type bool_expr =
  | True
  | False
  | Bool_op of num_expr * bool_op * num_expr
  | Not of bool_expr
  | And of bool_expr * bool_expr
  | Or of bool_expr * bool_expr

type instr = 
    [ `Create_func of string * string
    | `Create_int of string * num_expr
    | `Read of string
    | `Print of num_expr
    | `Affect of string * num_expr
    | `Send of string * string * num_expr list
    | `Recv of string * string * string list 
    | `Lock ]

type loc =
  | Global
  | Group of string
  | Agent of string

type arg =
  | Func of string
  | Int of string

type loc_instr = 
    [ instr
    | `If of bool_expr * initial list * initial list
    | `While of bool_expr * initial list 
    | `Join of string list
    | `Leave of string list ]

      
and initial = 
    [ `Instr of loc * loc_instr
    | `For of string * loc * initial list
    | `Call of string * (loc * num_expr list) list
    | `Proc of string * (loc * arg list) list * initial list 
    | `Start of string list 
    | `Stop of string list 
    | `Group of string list ]

type atomique =
    [ instr
    | `Case of bool_expr ]
          (*    | `Save 
	    | `Return *)

type io = [ `Input of int | `Output of int ]

type trace = [`Trace of string * atomique | `Nope ]

type trace_io = 
    [ trace | `Io of string * io ]


  
module Event =
struct
  type t = trace_io Box.t
  let compare e1 e2 = compare (Box.num e1) (Box.num e2)
  let equal e1 e2 = (Box.num e1) = (Box.num e2)
  let hash e1 = Hashtbl.hash (Box.num e1)
end
  
module G = Graph.Imperative.Digraph.Concrete(Event) 

type action =
    [ trace_io | initial | `Pomset of G.t ]





(*********** pretty-print ***********)
module type Draw =
sig
  val sep : string
  val beginline : string
  val endline : string
  val protect : string
  val times : string
  val div : string
  val le : string
  val leq : string
  val ge : string
  val geq : string
  val neq : string
  val true_ : string
  val false_ : string
  val not_ : string
  val loc : loc -> string
  val color : string -> string
end

module Pretty_print (G:Draw) =
struct
  let list_to_string to_string sep = function
    | [] -> ""
    | [h] -> to_string h
    | h :: t -> to_string h ^ List.fold_left (fun accu x -> accu ^ sep ^ " " ^ to_string x) "" t
	
  let num_op = function
    | Add -> "+"
    | Soustract -> "-"
    | Product -> G.times
    | Divide -> G.div
	
  let rec num_expr = function
    | Num i -> string_of_int i 
    | Var x -> x
    | Inv e -> "-" ^ num_expr e
    | Num_op (e, op, f) -> Printf.sprintf "(%s %s %s)" (num_expr e) (num_op op) (num_expr f)
    | Apply (f, args) -> Printf.sprintf "%s(%s)" f (list_to_string num_expr ", " args)
	
  let bool_op = function
    | Le -> G.le
    | Leq -> G.leq
    | Ge -> G.ge
    | Geq -> G.geq
    | Eq -> "="
    | Neq -> G.neq

  let rec bool_expr = function
    | True -> G.true_
    | False -> G.false_
    | Bool_op (e, op, f) -> Printf.sprintf "(%s %s %s)" (num_expr e) (bool_op op) (num_expr f)
    | Not b -> Printf.sprintf "%s %s" G.not_ (bool_expr b)
    | And (a,b) -> Printf.sprintf "(%s and %s)" (bool_expr a) (bool_expr b)
    | Or (a,b) -> Printf.sprintf "(%s or %s)" (bool_expr a) (bool_expr b)
	
  let id x = x
    
  let add_tab tab = G.sep^tab
    
  let var_to_string e_to_string (a,el) =
    Printf.sprintf "%s%s" (G.loc a) (list_to_string e_to_string ", "el)
      
  let args_to_string e_to_string l =
    list_to_string (var_to_string e_to_string) "; " l
      
  let assoc_to_string (x,e) =
    Printf.sprintf "%s -> %s" x (num_expr e)
      
  let arg = function
    | Func s -> Printf.sprintf "func %s" s
    | Int s -> Printf.sprintf "int %s" s

  let block tab b = 
    if b <> ""
    then Printf.sprintf "%s{%s%s%s%s%s} " G.protect G.endline b G.beginline tab G.protect
    else ""
      
  let pre_block tab b = 
    if b <> ""
    then Printf.sprintf "%s{%s{%s%s%s%s%s}%s} " G.protect G.protect G.endline b G.beginline tab G.protect G.protect
    else ""

  let else_ tab b = 
    if b <> ""
    then Printf.sprintf "else %s" (block tab b)
    else ""

  let agent a = G.loc (Agent a)

  let rec loc_instr_aux tab m = match (m:[atomique | io | loc_instr]) with
    | `If (b, then_code, else_code) -> 
	Printf.sprintf "if %s %s%s" (bool_expr b) 
	  (block tab (action_list_aux (add_tab tab) (then_code:>action list))) 
	  (else_ tab (action_list_aux (add_tab tab) (else_code:>action list)))
    | `While (b, code) -> 
	Printf.sprintf "while %s %s" (bool_expr b) (block tab (action_list_aux (add_tab tab) (code:>action list)))
    | `Join ml -> Printf.sprintf "join (%s)" (list_to_string id ", " ml)
    | `Leave ml -> Printf.sprintf "leave (%s)" (list_to_string id ", " ml)
    | `Create_func (f,a) -> Printf.sprintf "func %s = %s" f a (*"func %s = external %s" f a*)
    | `Read x -> "read " ^ x
    | `Print e -> "print " ^ num_expr e
    | `Create_int (x,e) -> Printf.sprintf "int %s = %s" x (num_expr e)
    | `Affect (x,e) -> Printf.sprintf "%s = %s" x (num_expr e)
    | `Send (b,m,el) -> Printf.sprintf "send %s(%s) to [%s]" m (list_to_string num_expr ", "el) b
    | `Recv (b,m,xl) -> Printf.sprintf "recv %s(%s) from [%s]" m (list_to_string id ", " xl) b
    | `Input (n) -> G.color (Printf.sprintf "in : %i" n)
    | `Output n -> G.color ("out: "^string_of_int n)
    | `Case b -> Printf.sprintf "case %s" (bool_expr b)
    | `Lock -> "lock"
    (*| `Save -> Printf.sprintf "save"
    | `Return ->  Printf.sprintf "return"*)

  and action_aux tab m = match (m:action) with
    | `Trace (a,i) -> Printf.sprintf "%s%s" (agent a) (loc_instr_aux tab (i:>[loc_instr|atomique|io]))
    | `Io (a,i) -> Printf.sprintf "%s%s" (agent a) (loc_instr_aux tab (i:>[loc_instr|atomique|io]))  
    | `Nope -> Printf.sprintf "%snope" tab
    | `Instr (l,i) ->  Printf.sprintf "%s%s" (G.loc l) (loc_instr_aux tab (i:>[loc_instr|atomique|io]))  
    | `Proc (p,args,code) -> 
	Printf.sprintf "proc %s(%s) %s" p (args_to_string arg args) (block tab (action_list_aux (add_tab tab) (code:>action list)))
    | `Call (p,args) -> Printf.sprintf "call %s(%s)" p (args_to_string num_expr args)
    | `For (a,b,code) -> Printf.sprintf "for %s in %s%s" a (G.loc b) (block tab (action_list_aux (add_tab tab) (code:>action list)))
    | `Start ml -> Printf.sprintf "start (%s)" (list_to_string id ", " ml)
    | `Stop ml -> Printf.sprintf "stop (%s)" (list_to_string id ", " ml)
    | `Group gl -> Printf.sprintf "group (%s)" (list_to_string id ", " gl) 
    | _ -> "not yet supported"

  and action_list_aux tab (code:action list) = 
    List.fold_left (fun accu v -> Printf.sprintf "%s%s%s%s;%s" accu G.beginline tab (action_aux tab v) G.endline) "" code

  let action a = action_aux "" (a:>action)
  let action_list l = action_list_aux "" (l:>action list)
end

let loc = function
  | Global -> ""
  | Group g -> "<"^g^"> "
  | Agent a -> "["^a^"] "

module Normal = 
struct
  let endline = "\n"
  let sep = "\t"
  let protect = ""
  let beginline = ""
  let times = "*"
  let div = "*"
  let le = "<"
  let ge = ">"
  let leq = "<="
  let geq = ">="
  let neq = "<>"
  let true_ = "true"
  let false_ = "false"
  let not_ = "not"
  let loc  = loc
  let color s = s
end

let action, action_list = let module M = Pretty_print(Normal) in M.action, M.action_list


module Latex = 
struct
  let endline = "\\\\\n"
  let sep = "\\ \\ \\ \\ \\ "
  let beginline = "\\ "  
  let protect = "\\" 
  let times = "$\\times$"
  let div = "$\\div"
  let le = "$<$"
  let leq = "$\\leq$"
  let ge = "$>$"
  let geq = "$\\geq$"
  let neq = "$\\neq$"
  let true_ = "\\texttt{true}"
  let false_ = "\\texttt{false}"
  let not_ = "$\\neg$"
  let color s = Printf.sprintf "\\textcolor{red}{%s}" s
  let loc = function
  | Global -> ""
  | Group g -> "$\\langle$"^g^"\\$rangle$ "
  | Agent a -> "["^a^"] "
end
  
let latex_action_list = let module M = Pretty_print(Latex) in M.action_list
								
module No_loc_latex =
struct
  include Latex
  let loc s = ""
end
  
let no_loc_action = let module M = Pretty_print(No_loc_latex) in M.action
								   


(*** fonctions de conversion de base ***)
let to_trace_io (m:action) = match m with
  | `Trace _ | `Io _ as k -> (k:>trace_io)
  | _ -> `Nope

let to_trace (m:action) = match m with
  | `Trace _ as k -> (k:>trace)
  | _ -> `Nope

let agent_of_action (a:action) = match a with
  | `Trace(a,_) | `Io(a,_) | `Instr(Agent a,_) -> a
  | _ -> "root"



(****** signatures de base *****)
module type Code =
sig 
  type t 
  val is_finished : t -> bool
  val next : t -> (string -> bool_expr -> bool) -> action * t
  (* val to_string : t -> string *)
end 


module type Model = 
sig 
  type t 
  type env
  val empty : unit -> t
  val to_string : t -> string    
  val output_model : string -> t -> unit 
  val combine_if : env -> (action -> action list) -> string -> bool_expr -> t -> t -> t 
  val combine_while : env -> (action -> action list) -> string -> bool_expr ->  t -> t
  val combine_call : env -> (action -> action list) -> string -> (loc * arg list) list -> (loc * num_expr list) list -> t -> t
  val combine : t -> t -> t
  val combine_action : t -> action -> t
end
