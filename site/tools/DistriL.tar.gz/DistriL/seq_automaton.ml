(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

(* un modele de calcul qui genere un automate ou les appels de call sont expanses et
   l'environnement lie au variable statiquement determine *)
open Base_types

open Automaton

module Arg = 
struct
  type t = trace automaton
  type label = trace
  let from_trace (a:trace) = (a:>label)
      
  let combine_action (m:t) (a:action) = 
    if a = `Nope 
    then m 
    else posptend m (to_trace a)

  let from_automaton x = x
  let to_automaton x = x
  let string_of_transition = transition_to_dot (function t -> action (t:>action))
end

module Model = Model(Arg)

module Code =
struct
  type t = trace Automaton.exec

  (* let to_action (a:t) = map_exec (fun x -> (x:>action)) a *)

  let is_finished = is_finished
    
  let rec next (code:t) eval_bool = 
    if Automaton.has_undefined_agents code
    then Automaton.declare_agent code 
    else
      (*Printf.eprintf "%i\n%s" code.Automaton.current_state (Model.to_string code.Automaton.automaton);*)
      match fireable (function `Trace(a, `Case b) -> eval_bool a b | _ -> true) code with
	| (_,m,s) :: _ ->  (m :> action), { code with current_state = s }
	| [] -> invalid_arg "Seq_automaton.next"
	  
  let make (a:Model.t) = make_exec (fun a -> [agent_of_action (a:>action)]) (map (fun x -> (x:trace)) a)
(*    { current_state = a.start; automaton = map to_trace a } *)
      
  let to_string (a:t) = 
    Model.to_string (map (function x -> (x:>trace)) a.automaton)
end

