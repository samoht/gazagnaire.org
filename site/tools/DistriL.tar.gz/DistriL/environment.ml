(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Base_types

type local_env =
    {       
      (* a garder lors du changement de contexte *)
      (* agent -> queue de messages *)
      buffer : ( (string * string) * (int list) list) list;

      (* memory : address -> value *)
      memory : ( int * int ) list;
      
      (* ca ca change quand on switche *)
      (* address : var -> adress *)
      address : ( string * int ) list;

      (* pour les fonctions :  f -> <abstr> *)
      func : ( string * string ) list;

      (* local i/o buffer *)
      input : int;
      output : int;
    }      
      
(* set a derouler *)
and global_env =
    {
      (* group reels -> agent list *)
      groups : (string * ( string list ) ) list;

      (* variables de localite : ca compte pour les agents et les groupes *)
      loc : (string * string) list;

      (* agents reels *)
      agent_names : string list;
      
      (* pour les procedures *)
      proc : ( string * (initial list *  t * ( loc * arg list) list )) list;
    }

and t =
    { local : (string * local_env) list ;
      global : global_env }



(**** pretty print ****)
let string_of_list p l =
  "[|"
  ^ begin
    match l with
      | [] -> ""
      | [h] -> p h
      | h::t -> p h ^ List.fold_left (fun accu e -> accu ^ "; " ^ p e) "" t
  end
  ^ "|]"
    
let string_of_assoc pk pv (k,v) =
  Printf.sprintf "%s -> %s" (pk k) (pv v) 
    
let id x = x
  
let couple (x,y) = 
  Printf.sprintf "(%s,%s)" x y

(* global *)
let string_of_groups env =
  "groups : "
  ^ string_of_list (string_of_assoc id (string_of_list id)) env.groups
  ^ "\n"
    
let string_of_loc env =
  "loc : "
  ^ string_of_list (string_of_assoc id id) env.loc
  ^ "\n"
    
let string_of_agent_names env =
  "agent_names : "
  ^ string_of_list (fun x -> x) env.agent_names
  ^ "\n"
    
let string_of_proc env =
  "proc : "
  ^ string_of_list (function (p,_) -> p) env.proc
  ^ "\n"


(* local *)
let string_of_buffer env =
  "buffer : "
  ^ string_of_list (string_of_assoc couple (string_of_list (string_of_list string_of_int))) env.buffer
  ^ "\n"
    
let string_of_address env =
  "address : "
  ^ string_of_list (string_of_assoc id string_of_int) env.address
  ^ "\n"
    
let string_of_memory env =
  "memory : "
  ^ string_of_list (string_of_assoc string_of_int string_of_int) env.memory
  ^ "\n"
    
let string_of_var env =
  "var : "
  ^ string_of_list (string_of_assoc id (function i -> string_of_int (List.assoc i env.memory))) env.address
  ^ "\n"
    
let string_of_func env =
  "func : "
  ^ string_of_list (string_of_assoc id id) env.func
  ^ "\n"

let to_string_local (a,env) =
  Printf.sprintf "agent %s:\n" a
  ^ "\t" ^ string_of_buffer env
  ^ "\t" ^ string_of_func env
  ^ "\t" ^ string_of_var env
  ^ "\t" ^ string_of_address env
  ^ "\t" ^ string_of_memory env

let to_string_global e =
  string_of_groups e
  ^ string_of_loc e
  ^ string_of_agent_names e
  ^ string_of_proc e

let to_string e =
  "global:\n"
  ^ to_string_global e.global
  ^ "local:\n"
  ^ List.fold_left (^) "" (List.map (to_string_local) e.local)

    
    
    
(***** constructeurs *******)
    
let local_empty () =
  { 
    input = 0;
    output = 0;
    buffer = [];
    address = [];
    memory = [];
    func = [];
  }

let global_empty () =
  {
    loc = [];
    agent_names = [];
    groups = [];
    proc = [];
  }

let empty () = 
  { global = global_empty (); 
    local = [] }
   

(********************* environnement locaux ***********************)
(********* variables ********)
(* on a deux niveaux d'indirection :
   -- d'abord les noms de variables pointent vers des localites 
   -- ensuite les localites pointent vers des valeurs *)
module Local =
struct
  type name =
      [ `Var of string 
      | `Message of string * string 
      | `Memory of int 
      | `Func of string ]

  let name = function
    | `Var x -> Printf.sprintf "Variable %s not found" x
    | `Memory x -> Printf.sprintf "Address x%i in memory is empty" x
    | `Func x -> Printf.sprintf "Function %s not found" x
    | `Message (x,m) -> Printf.sprintf "Message %s coming from %s not found" m x

  exception Bad_name of name * local_env
  let bad_name name env = raise (Bad_name (name, env))

  let address env v =
    if not (List.mem_assoc v env.address)
    then bad_name (`Var v) env
    else List.assoc v env.address
      
  let var env v =
    let l = address env v in
      if not (List.mem_assoc l env.memory)
      then bad_name (`Memory l) env
      else List.assoc l env.memory
	
  (* returne la position memoire de la variable *)
  let var_addr env v =
    Printf.sprintf "%s@%i" v (address env v)

  (* change la valeur associee a la localite ou pointe var *)
  let subst_var env v n = 
    let add = address env v in
      { env with memory = (add,n) :: List.remove_assoc add env.memory }
	

  (* ajoute une nouvelle localite vers ou pointe x *)
  let create_var env v n = 
    let sp = 
      List.fold_left (fun accu (s,_) -> max s accu) 0 env.memory + 1
    in
      { env with 
	  address = (v ,sp) :: List.remove_assoc v env.address; 
	  memory =  (sp, n) :: env.memory }
   
  let switch old_env new_env =
    { new_env with 
	memory = List.map (function (a,v) -> if List.mem_assoc a old_env.memory then (a,List.assoc a old_env.memory) else (a,v)) new_env.memory;
	buffer = old_env.buffer }


  (******* functions ******)
  let func_name env f =
    if List.mem_assoc f env.func
    then List.assoc f env.func
    else bad_name (`Func f) env
      
  let func env f = Lib.link (func_name env f)

  let load_func env f v =
    { env with func = (f, v) :: List.remove_assoc f env.func }
    

  (******* messages ******)
  let get_queue env a =
    if List.mem_assoc a env.buffer 
    then List.assoc a env.buffer
    else [] (*bad_name (`Message a) env*)
      
  (* on stocke localement le message provenant de a *)
  let queue_mess env a mess =
    { env with 
	buffer = (a, get_queue env a @ [mess]) :: List.remove_assoc a env.buffer }
    
  (* on va chercher le contenu du message provenant de a *)
  let unqueue_mess env a =
    match get_queue env a with
      | [] -> bad_name (`Message a) env
      | [h] -> h, { env with buffer = List.remove_assoc a env.buffer }
      | h :: t -> h, { env with buffer = (a, t) :: List.remove_assoc a env.buffer }

  (* i/o *)
  let input env () = env.input
  let output env () = env.output
  let set_input env n = { env with input = n }
  let set_output env n = { env with output = n }
end
  

module Global =
struct  
  type name =
      [ `Loc of string 
      | `Group of string ]
      
  let name = function
    | `Loc x -> Printf.sprintf "Locality %s not found" x
    | `Group x -> Printf.sprintf "Group %s not found" x

  exception Bad_name of name * global_env
  let bad_name name env = raise (Bad_name (name, env))    

  
  (***** localites *****)
  let get_loc env a =
    if List.mem_assoc a env.loc 
    then List.assoc a env.loc
    else bad_name (`Loc a) env
      
  let var_loc = function
    | Agent a -> Some a
    | Group g -> Some g
    | Global -> None

  let subst_loc env a n =
    match var_loc a, var_loc n with
      | Some a, Some n -> { env with loc = (a,n) :: List.remove_assoc a env.loc } 
      | _,_ -> env
            
  (********* agents ********)
  let agent env a =
    get_loc env a
	  
  let agent_names env =
    env.agent_names
      
  let exists_agent env a =
    List.mem a env.agent_names && List.mem_assoc a env.loc
    
  let create_agent env a =
    if exists_agent env a 
    then env
    else { env with 
	     agent_names = a :: env.agent_names;
	     loc = (a,a) :: env.loc }

  let kill_agent env a =
    if not (exists_agent env a)
    then bad_name (`Loc a) env
    else { env with 
	     agent_names = List.filter ((<>) a) env.agent_names;
	     loc = List.remove_assoc a env.loc }

  (****** groupes *******)
  let group env g =
    get_loc env g
      
  let create_group env g =
    { env with 
	loc = (g,g) :: List.remove_assoc g env.loc;
	groups = (g, []) :: List.remove_assoc g env.groups }
      
  let exists_group env g =
    List.mem_assoc g env.groups
      
  let agents_of_group env g =
    if exists_group env g
    then List.assoc (group env g) env.groups
    else bad_name (`Group g) env
      
  let is_in_group env g a =
    let g = group env g
    and a = agent env a
    in
      List.mem a (agents_of_group env g) 
      
  let add_group env g al =
    if not (exists_group env g) 
    then bad_name (`Group g) env
    else
      { env with 
	  groups = (g,al) :: List.remove_assoc g env.groups;
	  loc = (g, g) :: List.remove_assoc g env.loc }

  let add_in_group env g a =
    if not (exists_group env g)
    then bad_name (`Group g) env;
    let g = group env g      
    and a = agent env a 
    in
      if is_in_group env g a 
      then env
      else { env with groups =  (g, a :: agents_of_group env g) :: List.remove_assoc g env.groups }

  let remove_of_group env g a =
    let g = group env g
    and a = agent env a
    in 
      if is_in_group env g a
      then { env with groups =  (g, List.filter ((<>) a) (agents_of_group env g) ) :: List.remove_assoc g env.groups }
      else env
  
  (***** switch ****)
  let switch old_env new_env = 
    { new_env with 
	groups = old_env.groups;
	agent_names = old_env.agent_names }
end












(******  procedures ******)
type name = 
    [`Local of (string * Local.name) 
    | Global.name 
    | `Proc of string ]

exception Bad_name of name * t
let bad_name name env = raise (Bad_name (name, env))

let name x = match (x:name) with
  | `Local (a,l) -> Printf.sprintf "%s on agent %s" (Local.name l) a
  | `Proc p -> Printf.sprintf "Procedure %s not known" p
  | `Loc _ | `Group _  as m  -> Global.name (m:>Global.name)

let proc env p =
  if List.mem_assoc p env.global.proc
  then List.assoc p env.global.proc
  else bad_name (`Proc p) env
    
let create_proc env p args b =
  { env with global = { env.global with proc = (p, (b, env, args)) :: env.global.proc } } 
    
let proc_names env p =
  let _,_,names = proc env p in
    names

(* revoit tous les agents qui ont m dans leur groupe *)
(* let agents_of_group env m =
   List.fold_left (fun accu (a,env) -> if Local.is_in_group env m then a :: accu else accu) [] env.local *)

let switch old_env new_env =
  let aux a new_env_a = 
    if List.mem_assoc a old_env.local
    then Local.switch (List.assoc a old_env.local) new_env_a
    else new_env_a
  in
    { 
      local = List.map (function (a,new_env_a) -> (a, aux a new_env_a)) new_env.local;
      global = Global.switch old_env.global new_env.global;
    }

    
(****** consistance *****)
(* utilse pour le deroulage de calls *)
let compare_list l1 l2 = 
  compare (List.sort compare l1) (List.sort compare l2)

let compare_agent_names env1 env2 = 
  compare_list (Global.agent_names env1.global) (Global.agent_names env2.global)

let compare_loc env1 env2 = 
  compare_list env1.global.loc env2.global.loc

let compare_args (code1,env1,args1) (code2,env2,args2) =
  if compare (code1,args1) (code2,args2) <> 0
  then compare (code1,args1) (code2,args2)
  else if compare_agent_names env1 env2 <> 0
  then compare_agent_names env1 env2 
  else compare_loc env1 env2

(* c'est pas tout a fait complet mais si le programmeur n'est pas
   content il a qu'a fait des trucs moins tordus *)
let are_proc_equal env1 env2 =
  let aux (p1,args1) (p2,args2) = p1 = p2 && compare_args args1 args2 = 0 in 
  let sort l = List.sort (fun (p1,args1) (p2,args2) -> if compare p1 p2 = 0 then compare_args args1 args2 else compare p1 p2) l
  in
    List.fold_left (fun accu (a,b) -> accu && aux a b) true (List.combine (sort env1.global.proc) (sort env2.global.proc))

let are_consistent e f =
  compare_agent_names e f = 0 && compare_loc e f = 0 && are_proc_equal e f
  



(**** les trucs dont on a besoin a l'exterieur .... ****)
(* todo : c'est super moche, il faudrait reecrire les fonctions avec
   l'environnement tout le temps a la fin *)

(**** global ***)
let make_global env f =
  try
    { env with global = f env.global }
  with Global.Bad_name (n,_) -> bad_name (n:>name) env

let apply_global env f =
  try
    f env.global
  with Global.Bad_name (n,_) -> bad_name (n:>name) env


let add_in_group env g a =
  make_global env (function e -> Global.add_in_group e g a) 

let add_group env g al =
  make_global env (function e -> Global.add_group e g al) 

let remove_of_group env g a =
  make_global env (function e -> Global.remove_of_group e g a) 

let create_agent env a =
  try  { global = Global.create_agent env.global a;
	 local = if not (List.mem_assoc a env.local) then (a,local_empty ()) :: env.local else env.local }
  with Global.Bad_name (n,_) -> bad_name (n:>name) env

let kill_agent env a =
  try { global = Global.kill_agent env.global a;
	local = List.remove_assoc a env.local }
  with Global.Bad_name (n,_) -> bad_name (n:>name) env

(* let groups env g =
   apply_global env (function e ->  Global.groups e g) *)

let agents_of_group env g =
  apply_global env (function e -> Global.agents_of_group e g)

let agent env a =
  apply_global env (function e -> Global.agent e a)

let create_loc (env:t) (old_env:t) (l:loc) =
  match l with
    | Agent a -> create_agent env (agent old_env a)
    | Group g -> 
	let al = agents_of_group old_env g in
	  List.fold_left (fun accu a -> create_agent accu a) (add_group env g al) al
    | Global -> env

(* a -> b *)
let subst_loc env a b =
  make_global env (function e -> Global.subst_loc e a b)

let create_group env g = 
  make_global env (function e -> Global.create_group e g)

let get_loc env l =
  apply_global env (function e -> Global.get_loc e l)

(* est-ce que l'agent agent est dans le groupe g *)
let is_in_group env g agent =
  apply_global env (function e -> Global.is_in_group e g agent) 

let agent_names env =
  apply_global env Global.agent_names

let exists_agent env a =
  apply_global env (function e -> Global.exists_agent e a)








(*** local ***)
let mem_local a e =
  List.mem_assoc a e.local

let assoc_local a e = 
  if mem_local a e 
  then List.assoc a e.local
  else bad_name (`Loc a) e

let apply_local e f a x =
  try f (assoc_local a e) x
  with Local.Bad_name (x,_) -> bad_name (`Local (a,x)) e

let make_local env f a =
  if List.mem_assoc a env.local 
  then 
    try
      { env with local = (a, f (List.assoc a env.local)) :: List.remove_assoc a env.local }
    with Local.Bad_name (k,_) -> bad_name (`Local (a,k)) env
  else bad_name (`Loc a) env
    
let create_var env a v n = 
  make_local env (function e -> Local.create_var e v n) a 

let subst_var env a v n = 
  make_local env (function e -> Local.subst_var e v n) a

let load_func env a f v =
  make_local env (function e -> Local.load_func e f v) a

let switch_i a old_env new_env =
  { local = (a, Local.switch (assoc_local a old_env) (assoc_local a new_env)) :: List.remove_assoc a old_env.local;
    global = Global.switch old_env.global new_env.global }

(* l'agent "a" envoit a l'agent "b" le message sans nom mess *)
let queue_mess env a b mess =
  make_local env (function e -> Local.queue_mess e a mess) b

(* agent a is looking for a message coming from b *)
let unqueue_mess env a b =
  try
    let m, e = Local.unqueue_mess (assoc_local a env) b
    in
      m, { env with local = (a,e) :: List.remove_assoc a env.local } 
  with Local.Bad_name (n,_) -> bad_name (`Local (a,n)) env

let set_input env a n =
  make_local env (function e -> Local.set_input e n) a
let set_output env a n =
  make_local env (function e -> Local.set_output e n) a



let input env a =
  apply_local env Local.input a ()

let output env a =
  apply_local env Local.output a ()

let var env a v = 
  apply_local env Local.var a v

let func env a f =
  apply_local env  Local.func a f

let func_name env a f =
  apply_local env Local.func_name a f

let var_addr env a v =
  apply_local env Local.var_addr a v




