(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Base_types

module Code =
struct
  type t = initial list

  let is_finished c = c = []
  
  let next (code:t) _ = ( List.hd code :> action), List.tl code
    
  let to_string (code:t) = 
    "\\begin{tabular}{|l|}\n"
    ^"\\hline\n"
    ^"\\\\\n"
    ^latex_action_list (List.map (fun x -> (x:>action)) code)
    ^"\\\\\n"
    ^"\\hline\n"
    ^"\\end{tabular}\n"
end
