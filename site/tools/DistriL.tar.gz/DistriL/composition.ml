(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let extension = ".dep"

let control = ref false


let weak e1 e2 = 
  (Bmsc.instance e1) = (Bmsc.instance e2) ||
  match e1, e2 with 
    | `Trace(_,`Case _), _ -> !control
    | _,_ -> false
	

open Base_types

module Sset = Set.Make(struct type t = string * arg let compare = compare end)
open Sset

module type Arg =
sig
  val var : string * string -> Sset.t
  val write : string * string -> Sset.t
  val func : string * string -> Sset.t
end

module Fold (M:Arg) =
struct
  let rec num_expr a = function
    | Var v -> M.var (a,v)
    | Inv e -> num_expr a e
    | Num_op (e,_,f) -> union (num_expr a e) (num_expr a f)
    | Apply (s, el) -> List.fold_left union (M.func (a,s)) (List.map (num_expr a) el) 
    | Num _ -> empty
	
  let rec bool_expr a = function
    | Bool_op (e,_,f) -> union (num_expr a e) (num_expr a f)
    | Not b -> bool_expr a b
    | And (b,c) | Or (b,c) -> union (bool_expr a b) (bool_expr a c)
    | True | False -> empty

  let instr a = function
    | `Read x -> M.write (a,x)
    | `Print e -> num_expr a e
    | `Affect (x,e) | `Create_int (x,e) -> union (M.write (a,x)) (num_expr a e) 
    | `Send (_, _, el) -> List.fold_left union empty (List.map (num_expr a) el) 
    | `Recv (_, _, xl) -> List.fold_left union empty (List.map (function x -> M.write (a,x)) xl)
    | `Create_func (f,_)  -> M.func (a,f)
    | `Case b -> bool_expr a b
    | _ -> empty

  let trace_io (m:Bmsc.label) = match m with
    | `Trace(a,i)-> instr a i
    | _ -> empty
end

module Read = Fold(struct 
		     let var (a,v) = singleton (a, Int v) 
		     let func (a,f) = empty
		     let write (a,v) = empty 
		   end)

module Write = Fold(struct 
		     let var (a,v) = empty 
		     let func (a,f) = singleton (a, Func f)  
		     let write (a,v) = singleton (a, Int v) 
		   end)



let is_io = function
  | `Trace (_, `Read _) | `Trace (_, `Print _) -> true
  | `Io _ -> true
  | _ -> false

(* let context = function
   | `Trace(_,`Save) | `Trace(_,`Return) -> true
   | _ -> false *)

(* let is_affect i = not (is_empty (Write.trace_io i)) *)
   
let agent_of_label (a:Bmsc.label) = agent_of_action (a:>action)

let are_dependent m1 m2 =
  let aux (m1:Bmsc.label) (m2:Bmsc.label) = match m1,m2 with
	
    (* dependance lie au changement de contexte *)
    (*    | m1,m2 when agent_of_label m1 = agent_of_label m2 && context m1 && context m2 -> true 
	  | m1,m2 when agent_of_label m1 = agent_of_label m2 && context m1 && is_affect m2 -> true  *)

    (* dependance de messages *)
    | `Trace(a, `Send(b,m,_)), `Trace(c, `Send(d,n,_)) 
    | `Trace(a, `Recv(b,m,_)), `Trace (c, `Recv(d,n,_)) -> a = c && b = d && m = n

    (* dependances de sorties *)
    | m1,m2 when agent_of_label m1 = agent_of_label m2 && is_io m1 && is_io m2 -> true

    (* dependance de variables/fonctions *)
    | m1, m2 -> 
	inter (Read.trace_io m1) (Write.trace_io m2) <> empty
	||  inter (Write.trace_io m1) (Write.trace_io m2) <> empty
  in
  let case m1 m2 = 
    match m1,m2 with
      | `Trace(_,`Case _), _ -> !control
      | _,_ -> false
  in
  let lock m1 m2 =
    match m1,m2 with
      | `Trace(a,`Lock), `Trace(b,_) | `Trace(a,`Lock), `Io(b,_) -> a = b
      | _,_ -> false
  in
    aux m1 m2  || aux m2 m1 || case m1 m2 || lock m1 m2 || lock m2 m1


let predicate = 
  ref (fun (m1:Bmsc.label) (m2:Bmsc.label) -> are_dependent m1 m2) 
(*  ref (fun (m1:Bmsc.label) (m2:Bmsc.label) -> bmsc m1 m2) *)

let set_predicate = function
  | "weak" -> predicate := weak
  | "causal" -> predicate := are_dependent
  | _ -> failwith "Composition.set_predicate"

