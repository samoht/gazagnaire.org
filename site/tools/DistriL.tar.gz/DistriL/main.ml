(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let _ = Random.self_init ()
let _ = Random.init 1000

exception Parse_error of int * int

let parse lexbuf =
  Lexer.line := 0;
  try 
    Parser.prog Lexer.main lexbuf
  with
    Parsing.Parse_error ->
      let p = lexbuf.Lexing.lex_curr_p in
	raise
	  (Parse_error (!Lexer.line,
			p.Lexing.pos_bol)
	  )

let toto = "je rajoute un nouveau truc"

let parse_file file =
  let ic = open_in file in
  let lexbuf = Lexing.from_channel ic in
    try let p = parse lexbuf in 
      close_in ic; 
      p
    with e -> 
      close_in ic; raise e

let parse_string s = 
  parse (Lexing.from_string s)

let parse_stdin () =
  parse (Lexing.from_channel stdin)

let write_file f s =
  let c = open_out f in
    output_string c s;
    close_out c

let input_file = ref ""
let output_trace = ref "trace.png"
let output_model = ref "model.png"
let model = ref "pomset"
let trace = ref "pomset"

open Eval
open Tools

let _ =
  Arg.parse
    (Arg.align
       [ "-d", Arg.Set Tools.debug_, " Execute the evaluation in debug mode.";
	 "-q", Arg.Clear Tools.verbose_, " Execute the evaluation in quiet mode (name of external commands called are not printed).";
	 "-c", Arg.Symbol ( [ "weak"; "causal" ], Composition.set_predicate), 
	 " Change the predicate use for composing msc (default : causal). Possible predicates are : causal / weak.";
	 "-control", Arg.Set Composition.control,
	 "use semi-trace composition for modeling control (not set by default).";
         "-f", Arg.Set_string Draw_pomset.img, 
	 " Change the drawing format (default: pgf). Possible formats are: graph / bmsc / pgf.";
	 "-model", Arg.Set_string model, 
	 " Change the model of computation (default : pomset). Possible models are: pomset / seq /none.";
         "-m", Arg.Set_string output_model, 
	 " Change the output file name for the model (default: model.png). If set to \"\", then the model is not exported.";
	 "-trace", Arg.Set_string trace, 
	 " Change the model of output traces (default :pomset). Possible models are:pomset / seq / big_step / none.";
         "-t", Arg.Set_string output_trace, 
	 " Change the output file name for the execution (default: trace.png). If set to \"\", then the trace is shown on stdout." ])
    (function s -> input_file := s)
    (Printf.sprintf "\tDistril 0.5\tauthor : T. Gazagnaire <thomas.gazgnaire@gmail.com>\taugust 2007\n\nusage: %s  [-d] [input_file] [-t output_file] [-trace model] [-m model_file] [-model model] [-f drawing_format]\n" Sys.argv.(0));
  
  let code = 
    if !input_file = "" 
    then parse_stdin ()
    else parse_file !input_file
  
  and out_model =
    if !output_model = ""
    then output_string stdout
    else write_file !output_model
  in
  
    try
      match !model, !trace with

	| "pomset", t ->
	    info "Building pomset model ...";
	    let a =  Programm_to_pomset_automaton.main code in
	      info "... OK\n";
	      Pomset_automaton.Model.output_model !output_model a;
	      let c = Pomset_automaton.Code.make a in
		begin
		  match t with 
		    | "pomset" -> 
			info "Building pomset trace ...\n";
			let t = Pomset_automaton_to_pomset_trace.main c in
			  Pomset_trace.Model.output_model !output_trace t
		    | "seq" -> 
			info "Building seq model ...";
			let t = Pomset_automaton_to_seq_trace.main c in
			  info "... OK\n";
			  Seq_trace.Model.output_model !output_trace t
		    | "big_step" ->
			info "Building big step model ...";
			let c = Pomset_automaton.Big_step.make a in
			let t = Pomset_automaton_to_pomset_trace_big_step.main c in
			  info "... OK\n";
			  Pomset_trace.Big_step.output_model !output_trace t

		    | "none" -> ()
		    | s -> failwith (Printf.sprintf "%s: trace model not supported.\n" s)
		end

	| "seq", t ->
	    info "Building seq model ...";
	    let a =  Programm_to_seq_automaton.main code in
	      info "...OK\n";
	      Seq_automaton.Model.output_model !output_model a;
	      let c = Seq_automaton.Code.make a in
		begin
		  match t with 
		    | "pomset" -> 
			info "Building pomset trace ...\n";
			let t = Seq_automaton_to_pomset_trace.main c in
			  info "...OK\n";
			  Pomset_trace.Model.output_model !output_trace t
		    | "seq" -> 
			info "Building seq trace ...\n";
			let t = Seq_automaton_to_seq_trace.main c in
			  info "...OK\n";
			  Seq_trace.Model.output_model !output_trace t
		    | "none" -> ()
		    | s -> failwith (Printf.sprintf "%s: trace model not supported.\n" s)
		end
	| "none", "pomset" ->
	    info "Building pomset trace ...\n";
	    let t = Programm_to_pomset_trace.main code in
	      Pomset_trace.Model.output_model !output_trace t
		
	| "none", "seq" ->
	    info "Building seq trace ...\n";
	    let t =  Programm_to_seq_trace.main code in
	      Seq_trace.Model.output_model !output_trace t

	| "none", "none" -> out_model (Programm.Code.to_string code); flush stdout

	| s,t -> failwith (Printf.sprintf "%s -> %s: conversion not supported.\n" s t)

    with End -> ()


