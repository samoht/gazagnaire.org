(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let trash_dir = "trash/"
let dot_path = "/usr/local/graphviz-2.12/bin/"
let font = "/System/Library/Fonts/Times.dfont"
let draw = "png"

(****debug****)
let debug_ = ref false
let verbose_ = ref true

let debug s =
  if !debug_ 
  then begin 
    Printf.eprintf "%s" s;
    flush stderr
  end

let info s =
  if !verbose_ 
  then begin 
    Printf.eprintf "%s" s;
    flush stderr
  end

let debug_endline s =
  debug (s ^ "\n")

let info_endline s =
  info (s ^ "\n")

let execute s =
  info (Printf.sprintf "external command: %s\n" s);
  ignore (Sys.command s)


(****graph****)
module Level = functor (G : Graph.Sig.G) ->
struct
  exception Cyclic

  module T = Graph.Topological.Make(G)
  let level g =
    let l = Hashtbl.create 999 in
    let h x =
      if G.in_degree g x = 0 then 0
      else 1 + (G.fold_pred (fun v1 accu -> max (Hashtbl.find l v1) accu) g x 0)
    in
      T.iter (function v -> Hashtbl.add l v (h v)) g;
      function v -> if Hashtbl.mem l v then Hashtbl.find l v else raise Cyclic

  let distance g =
    let l = Hashtbl.create 999 in
    let h x =
      if G.in_degree g x = 0 then 0
      else 1 + (G.fold_pred (fun v1 accu -> min (Hashtbl.find l v1) accu) g x 0)
    in
      T.iter (function v -> Hashtbl.add l v (h v)) g;
      function v -> if Hashtbl.mem l v then Hashtbl.find l v else raise Cyclic

  let decomposition f g =
    let part = Hashtbl.create 999 in
    let indices = ref [] in
    let add e =
      let n = f e in
	if not (Hashtbl.mem part n) then indices := n :: !indices;
	Hashtbl.add part n e;
    in
      G.iter_vertex add g;
      List.map (Hashtbl.find_all part) (List.sort compare !indices)

  let max g = 
    G.fold_vertex (fun v accu -> if G.out_degree g v = 0 then v :: accu else accu) g []

  let min g = 
    G.fold_vertex (fun v accu -> if G.in_degree g v = 0 then v :: accu else accu) g []
end

module Transitive (G : Graph.Sig.I) =
struct
  module Oper = Graph.Oper.I(G)

  (* a priori on s'en fout de ce qu'il y a sur les arretes *)
  (* si on veut bien faire faudrait faire des operations de fusion ...
     mais bon on s'en fout ... *)
  let reduction g =
    let gc = Oper.transitive_closure g in
    let gcc = G.create () 
    and result = G.create ()
    in
      G.iter_vertex (G.add_vertex gcc) g;
      G.iter_vertex (G.add_vertex result) g;
      (* pour chaque arrete (u,w) de g, pour chaque (w,v) dans gc, on ajoute  (u,v) dans gcc *)
      G.iter_edges (fun u w -> G.iter_succ (fun v -> if w <> u && w <> v then G.add_edge gcc u v) gc w) g;
      (* on renvoit result = g - gcc *)
      G.iter_edges (fun u v -> if not (G.mem_edge gcc u v) then G.add_edge result u v) g;
      result
end

module Project (G : Graph.Sig.I) =
struct
  module Oper = Graph.Oper.I(G)
  module Reduc = Transitive(G)

  let project is_proj g =
    let g2 = G.create () in
    let gc = Oper.transitive_closure g in
    let add_vertex v =
      if is_proj v then G.add_vertex g2 v
    in
    let add_edge e =
      if is_proj (G.E.src e) && is_proj (G.E.dst e)
      then G.add_edge_e g2 e
    in
      G.iter_vertex add_vertex g;
      G.iter_edges_e add_edge gc;
      Reduc.reduction g2
end


