(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

exception Load_failed of string
exception Bad_arity of string * int * int

let fact n = 
  let rec aux accu k =
    if k > 1 
    then aux (k*accu) (k-1)
    else accu
  in
    aux 1 n

let square x = x * x

let random n = 
  if n>0 then Random.int n
  else if n = 0 then 0
  else - (Random.int n)

let max a b = 
  max a b

let id x = x



let arite1 n f = function
  | [h] -> f h
  | l -> raise (Bad_arity (n,1, List.length l))

let arite2 n f = function
  | [h;g] -> f h g
  | l -> raise (Bad_arity (n,2, List.length l))


let table = 
  [ "id", arite1 "id" id;
    "fact", arite1 "fact" fact;
    "square", arite1 "square" square;
    "random", arite1 "random" random;
    "max", arite2 "max" max  ]

let link a =
  if not (List.mem_assoc a table)
  then raise (Load_failed a)
  else List.assoc a table

