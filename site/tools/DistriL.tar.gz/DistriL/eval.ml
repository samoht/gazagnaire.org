(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Tools
open Base_types
module Env = Environment

module type Sig =
sig
  type source
  type cible
  val main : source -> cible
end

exception End

let error e =
  Printf.eprintf "\n\nError: %s\n\n" e;
  flush stdout;
  raise End

(* pour transformer du code Disril en un autre truc. Voir les stategy d'evaluation dans strategy.ml *)
module Make 
  (Source:Code)
  (Cible:Model with type env = Environment.t)
  (Eval:Oper.Sig)
  (Decode:sig val f : Env.t -> Env.t -> action -> action list end) =
struct 

  exception Already_running of string * Env.t
  exception Branching_inconsistency of Env.t * Env.t
  exception Invalid_argument_call of string * Env.t
  exception Invalid_message_format of string * string * Env.t

  type source = Source.t
  type cible = Cible.t

  type context =
      { stack : (string * Env.t) list;
	model : Cible.t;
	env : Env.t }

  let empty_context () =
    { stack = [];
      model = Cible.empty ();
      env = Env.empty () }

  let stack_is_empty c =
    c.stack = []
    
  let to_action l = List.map (fun x -> (x:>action)) l
  
  let add_loc_vars env old_env a vars =
    List.fold_left (function accu -> function 
		      Int x, e -> Env.create_var accu a x (Eval.num_expr (Env.var old_env a) (Env.func old_env a) e)
		    | Func f, Var v -> Env.load_func accu a f v
		    | _,_ -> failwith "eval.add_loc_vars"
		   ) env vars

  let add_vars env old_env (vars: (loc * (arg * num_expr) list) list ) =
    let rec aux v accu = function
      | Agent a -> add_loc_vars accu old_env a v
      | Group g -> List.fold_left (aux v) accu (List.map (fun a -> Agent a) (Env.agents_of_group old_env g))
      | Global -> List.fold_left (aux v) accu (List.map (fun a -> Agent a) (Env.agent_names env))
    in  
      List.fold_left (fun accu (a,v) -> aux v accu a) env vars

  let combine agents vars =
    List.map (function (a,(xl,el)) -> a, (List.combine xl el)) (List.combine agents vars)

  let same_loc e f = match e, f with
    | Agent _, Agent _ | Global, Global | Group _, Group _ -> true
    | _,_ -> false

  let check_args_names args names = 
    List.length args = List.length names 
    && List.fold_left (fun accu ((e,a),(f,b)) -> accu && same_loc e f && List.length a = List.length b) true (List.combine args names)

  let map_loc f = function
    | Agent a -> Agent (f a)
    | Group g -> Group (f g)
    | Global -> Global

(* l'appel de procedure avec liaison statique et appel par valeur donne des resultats surprenant. En effet, comme on passe
   le nom des agents (ou des groupes d'agents) et pas un pointeur vers leur memoire, on est incapable de recuperer leur
   buffer de messages. Et donc on ne peut pas matcher des messages qui viennent de l'exterieur de l'appel de fonction.
   C'est plutot un bon point pour les HMSC car ca veut dire qu'il n'y aura pas de messages a recoller. Mais ce n'est 
   pas super intuitf, surtout quand on est pas au courant :) *)
  let eval_call block context p args =
    (* on recupere l'ancien environnement *)
    let code, old_env, names = Env.proc context.env p in
      if not (check_args_names args names) 
      then raise (Invalid_argument_call (p,context.env))
      else
	(* on switche le contexte pour retrouver celui present lors 
	   de la creation de la procedure. Rappel : sont presents seulement
	   les agents actifs au moment de la creation de la procedure. Le switch 
	   permet de mettre a jour la memoire de ces agents. *)
      let call_env = Env.switch context.env old_env in
      let loc_args,var_args = List.split args in
      let loc_names,var_names = List.split names in
      let loc_args = List.map (map_loc (Env.get_loc context.env)) loc_args in
      let loc = List.combine loc_names loc_args in
	
      (* on lie les noms d'agents passes en argument, evalues dans 
	 le contexte d'appel (liaison statique). *)
      let call_env = List.fold_left (fun accu l -> Env.create_loc accu context.env l) call_env loc_args in  
      let call_env = List.fold_left (fun accu (a,n) -> Env.subst_loc accu a n) call_env loc in 
	
      (* on lie les noms de variable passes en argument, evalue eux 
	 aussi dans le context courant (liaison statique). *)
      let call_env = add_vars call_env context.env (combine loc_args (List.combine var_names var_args)) in
	(* finalement, on appelle le corps de la procedure, avec le contexte
	   qu'on vient de construire. *)
      let end_call_context = block { context with model = Cible.empty (); env = call_env } (to_action code) in
      let call_model = 
	Cible.combine_call call_env (Decode.f context.env call_env) p names (List.combine loc_args var_args) end_call_context.model
      in
      let end_call_env = Env.switch end_call_context.env context.env in
	assert (end_call_context.stack = context.stack);
	{ end_call_context with model =  Cible.combine context.model call_model; env = end_call_env } 
	  

  let agent_list context = function
    | Global -> List.rev (Env.agent_names context.env)
    | Group g -> List.rev (Env.agents_of_group context.env (Env.get_loc context.env g))
    | Agent a -> [Env.get_loc context.env a]

  let eval_for block (context:context) (a:string) (b:loc) (code:action list) =
    let aux accu c = block { accu with env = Env.subst_loc accu.env (Agent a) (Agent c) } code in
    let new_context = List.fold_left aux context (agent_list context b) in
    let new_env = Env.switch new_context.env context.env in
      { new_context with env = new_env }

  let eval_if (block:context -> action list -> context) context a b then_code else_code = 
    let then_test = Eval.bool_expr (Env.var context.env a) (Env.func context.env a) b    
    and else_test = Eval.bool_expr (Env.var context.env a) (Env.func context.env a) (Not b) in
    let then_context =
      if then_test
      then block { context with model = Cible.empty () } then_code
      else { context with model = Cible.empty () }
    and else_context =
      if else_test
      then block { context with model = Cible.empty () } else_code
      else { context with model = Cible.empty () }
    in
    let cont_model = Cible.combine_if context.env (Decode.f context.env context.env) a b then_context.model else_context.model in
    let cont_context = if then_test then then_context else else_context in
      if not (Eval.check_consistency) || 
	(Env.are_consistent then_context.env else_context.env && else_context.stack = then_context.stack)
      then { cont_context with model = Cible.combine context.model cont_model }
      else raise (Branching_inconsistency (then_context.env, else_context.env))


  let rec eval_while block context a b code =
    let while_test = Eval.bool_expr (Env.var context.env a) (Env.func context.env a) b 
    and leave_test = Eval.bool_expr (Env.var context.env a) (Env.func context.env a) (Not b) in
    let while_context =
      if while_test 
      then block { context with model = Cible.empty () } code
      else { context with model = Cible.empty () }
    in
    let cont_context =
      if leave_test 
      then while_context 
      else eval_while block while_context a b code
    in
      if not (Eval.check_consistency) || (Env.are_consistent context.env while_context.env && context.stack = while_context.stack)
      then { cont_context with 
	       model = Cible.combine context.model 
	  (Cible.combine_while context.env (Decode.f context.env context.env) a b cont_context.model)  }
      else raise (Branching_inconsistency (context.env, while_context.env))
	
  let rec instr context a = function 
      
    (* ici les noms d'agent sont des vrais agents *)
    | `Create_func (f,v) ->
	{ context with env = Env.load_func context.env a f v }
	  
    | `Create_int (x,e) ->
	{ context with env = Env.create_var context.env a x (Eval.num_expr (Env.var context.env a) (Env.func context.env a) e) }

    | `Read x -> 
	let n = Eval.read a x in
	  { context with env = Env.subst_var (Env.set_input context.env a n) a x n }

    | `Print e -> 
	let n = Eval.num_expr (Env.var context.env a) (Env.func context.env a) e in
	  Eval.print a (Eval.num_expr (Env.var context.env a) (Env.func context.env a) e); 
	  { context with env = Env.set_output context.env a n }
	    
    | `Affect (x,e) ->
	{ context with env = Env.subst_var context.env a x (Eval.num_expr (Env.var context.env a) (Env.func context.env a) e) }
	      
    | `Send (b,m,el) ->
	if a = b 
	then (Tools.info (Printf.sprintf "warning: %s is sending a message to itself. Instruction skipped.\n" a); context)
	else { context with 
		 env = Env.queue_mess context.env (a,m) b 
	    (List.map (Eval.num_expr (Env.var context.env a) (Env.func context.env a)) el) }
	  
    | `Recv (b,m,xl) ->
	if a = b 
	then (Tools.info (Printf.sprintf "warning: %s is receiving a message from itself. Instruction is skipped.\n" a); context)
 	else
	  let nl, context_env = Env.unqueue_mess context.env a (b,m) in
	    if List.length xl <> List.length nl
	    then raise (Invalid_message_format (a,b,context.env))
	    else 
	      let vars = List.map (function x -> (a,x)) xl in
	      let subst_list = List.combine vars nl in
		{ context with env = List.fold_left (fun accu ((a,x),n) -> Env.subst_var accu a x n) context_env subst_list }
		  
    | `If(b, then_code, else_code) -> eval_if action_list context a b (to_action then_code) (to_action else_code)

    | `While (b,code) -> eval_while action_list context a b (to_action code)

    | `Join gl -> { context with env = List.fold_left (fun accu g -> Env.add_in_group accu g a) context.env gl }

    | `Leave gl -> { context with env = List.fold_left (fun accu g -> Env.remove_of_group accu g a) context.env gl }    

 (*    | `Return -> { context with stack = List.remove_assoc a context.stack; 
      env = Env.switch_i a context.env (List.assoc a context.stack) }
      | `Save -> { context with stack = ( a,context.env ) :: context.stack }  *)

    | _ -> context

  and action context (m:action) =
    debug (Env.to_string context.env); 
    debug "\nACTION:\n";
    debug_endline (Base_types.action m);
    debug "\n";
    let model con = 
      { con with model = List.fold_left Cible.combine_action con.model (Decode.f con.env con.env m) }    
    in match m with
	(*ici la conversion des noms d'agent n'est pas encore faite *)
    | `Start al ->
	let start context a = 
	  if Env.exists_agent context.env a 
	  then raise (Already_running (Env.agent context.env a, context.env))
	  else { context with env = Env.create_agent context.env a }
	in
	  List.fold_left start context al
    | `Stop al ->
	{ context with env = List.fold_left (fun accu a -> Env.kill_agent accu (Env.agent context.env a)) context.env al }
    | `Instr (Agent a, `Send (b,m,e)) -> 
	model (instr context (Env.agent context.env a) (`Send(Env.agent context.env b,m,e)))
    | `Instr (Agent a, `Recv (b,m,e)) -> 
	model (instr context (Env.agent context.env a) (`Recv(Env.agent context.env b,m,e)))
    | `Instr (Agent a, `Join l) -> 
	model (instr context (Env.agent context.env a) (`Join (List.map (Env.get_loc context.env) l)))
    | `Instr (Agent a, `Leave l) -> 
	model (instr context (Env.agent context.env a) (`Leave (List.map (Env.get_loc context.env) l)))

    | `Instr (Agent a, i) ->  model (instr context (Env.agent context.env a) (i:>[loc_instr|atomique|io]))
    | `Instr (l,i) -> action_list context (List.map (function a -> `Instr (Agent a,i)) (agent_list context l))
    | `Proc (p, args, code) -> model { context with env =  Env.create_proc context.env p args code }
    | `Call (p, args) -> eval_call action_list (model context) p args
    | `For (a,b,code) -> eval_for action_list (model context) a b (to_action code)
    | `Trace (a,i) -> model (instr context (Env.agent context.env a) (i:>[loc_instr|atomique|io]))
    | `Group gl -> { context with env = List.fold_left (fun accu g -> Env.create_group accu g) context.env gl }

    (*      | `Pomset p -> { context with model = Cible.combine_pomset context.model p }  *)
    | _ -> context

  and action_list context l = List.fold_left action context l

  let rec action_iter context code = 
    if Source.is_finished code 
    then context
    else let a, code = Source.next code (fun a b -> Eval.bool_expr (Env.var context.env a) (Env.func context.env a) b) in
      action_iter (action context a) code
	
  let partial_main env code =
    try
      let c = empty_context () in
      let context = action_iter { c with env = env } code in
	debug (Env.to_string context.env); 
	context
    with 
      | Env.Bad_name (n,env) -> 
	  error (Printf.sprintf "%s.\n%s" (Env.name n) (Env.to_string env))
	    
      | Already_running (a,env) -> 
	  error (Printf.sprintf "Agent %s is already running.\n%s" a (Env.to_string env))
	    
      | Branching_inconsistency(env1, env2) ->
	  error (Printf.sprintf "Branching inconsistency.\n%s\n%s" (Env.to_string env1) (Env.to_string env2))

      | Invalid_argument_call (p,env) ->
	  error (Printf.sprintf "Invalid argument of call to %s.\n%s" p (Env.to_string env))

      | Invalid_message_format (i,j,env) ->
	  error (Printf.sprintf "Invalid format in a message from agent %s to agent %s.\n%s" i j (Env.to_string env))

      | Lib.Load_failed p ->
	  error (Printf.sprintf "Impossible to load the function %s.\n%s" p (Env.to_string env))

      | Lib.Bad_arity (f,i,j) ->
	  error (Printf.sprintf "Function %s is of arity %i but it is used with %i arguments.\n%s" f i j (Env.to_string env))


  let main code = (partial_main (Env.empty ()) code).model
end

module To_trace_io =
struct
  let rec num_expr var func = function
    | Num i -> Num i
    | Var v -> Var (var v)
    | Inv e -> Inv (num_expr var func e)
    | Num_op (e, op, f) -> Num_op (num_expr var func e, op, num_expr var func f)
    | Apply (f,args) -> Apply (func f, List.map (num_expr var func) args)
    
  let rec bool_expr var func = function
    | Bool_op (e,op,f) -> Bool_op(num_expr var func e, op, num_expr var func f)
    | Not b -> Not (bool_expr var func b) 
    | And(a,b) -> And(bool_expr var func a, bool_expr var func b)
    | Or(a,b) -> Or(bool_expr var func a, bool_expr var func b)
    | True | False as k -> k

  let loc_instr agent old_var var func m = match (m:>[loc_instr|atomique]) with
    | `Create_int (x,e) -> Some (`Create_int(var x, num_expr old_var func e))
    | `Create_func (f,p) -> Some (`Create_func(f, p))
    | `Affect (x,e) -> Some (`Affect (var x, num_expr old_var func e))
    | `Read x -> Some (`Read (var x))
    | `Print e -> Some (`Print (num_expr var func e))
    | `Send (b,m,e) -> Some (`Send(agent b, m, List.map (num_expr var func) e))
    | `Recv (b,m,x) -> Some (`Recv(agent b, m, List.map var x))
    | `Lock -> Some `Lock
    | _ -> None
     
  let case var func = function
    | `Case b -> `Case( bool_expr var func b ) 

  let f old_env env (x:action) = 
(*    Printf.eprintf "%s\n" (Base_types.action x); *)
    match x with
    | `Instr (Agent a, `Read x) -> 
	[`Io (Env.agent env a, `Input (Env.input env a)); 
	 `Trace(Env.agent env a, `Read (Env.var_addr env a x)) ]
    | `Instr (Agent a, `Print e) -> 
	let a = Env.agent env a in
	  [`Trace(a, `Print (num_expr (Env.var_addr env a) (Env.func_name env a) e));
	   `Io (a, `Output (Env.output env a));  ]
    | `Instr (Agent a, i) -> 
	begin
	  let a = Env.agent env a in
	    match loc_instr (Env.agent env) (Env.var_addr old_env a) (Env.var_addr env a) (Env.func_name env a) i with
	      | None -> []
	      | Some k -> [`Trace(a, k)]
	end
    | `Trace (a, `Read x) -> 
	[`Io (a, `Input (Env.input env a)); `Trace(a, `Read x) ]
    | `Trace (a, `Print e) -> 
	[`Trace(a, `Print e); `Io (a, `Output (Env.output env a));  ]
    | `Trace (a, `Case b) -> [`Trace (a, case (Env.var_addr env a) (Env.func_name env a) (`Case b))]
    | `Trace (a,i) -> [`Trace (a,i)]
	(*	begin
		match loc_instr (Env.agent env) (Env.var_addr old_env a) (Env.var_addr env a) (Env.func_name env a) i with
		| None -> []
		| Some k -> [`Trace(a, k)]
		end*)
    | `Io _ as k -> [(k:>action)]
    | _ -> []
end 

module To_trace =
struct
  let f old_env env (x:action) = 
    let rec aux = function
    | `Trace _  as k :: t -> (k:>action) :: aux t
    |  _ :: t -> aux t
    | [] -> []
    in
      aux (To_trace_io.f old_env env x)
end

module To_pomset =
struct 
  let f old_env env = function 
    | `Pomset p -> [`Pomset p]
    | _ -> []
end

module Programm_to_seq_trace = Make(Programm.Code)(Seq_trace.Model)(Oper.Normal)(To_trace_io)
module Programm_to_seq_automaton = Make(Programm.Code)(Seq_automaton.Model)(Oper.Always_true)(To_trace)
module Programm_to_pomset_trace = Make(Programm.Code)(Pomset_trace.Model)(Oper.Normal)(To_trace_io)
module Programm_to_pomset_automaton = Make(Programm.Code)(Pomset_automaton.Model)(Oper.Always_true)(To_trace)

module Seq_automaton_to_seq_trace = Make(Seq_automaton.Code)(Seq_trace.Model)(Oper.Normal)(To_trace_io)
module Seq_automaton_to_pomset_trace = Make(Seq_automaton.Code)(Pomset_trace.Model)(Oper.Normal)(To_trace_io)
module Seq_automaton_to_pomset_automaton = Make(Seq_automaton.Code)(Pomset_automaton.Model)(Oper.Always_true)(To_trace)

module Pomset_automaton_to_seq_trace = Make(Pomset_automaton.Code)(Seq_trace.Model)(Oper.Normal)(To_trace_io) 
module Pomset_automaton_to_seq_automaton = Make(Pomset_automaton.Code)(Seq_automaton.Model)(Oper.Normal)(To_trace_io) 
module Pomset_automaton_to_pomset_trace = Make(Pomset_automaton.Code)(Pomset_trace.Model)(Oper.Normal)(To_trace_io) 
module Pomset_automaton_to_pomset_trace_big_step = Make(Pomset_automaton.Big_step)(Pomset_trace.Big_step)(Oper.Always_true)(To_pomset)
