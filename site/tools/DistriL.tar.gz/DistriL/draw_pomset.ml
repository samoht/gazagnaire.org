(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = Tools.files_dir
let trash_dir = Tools.trash_dir
let ext = Pomset.ext
let draw = Tools.draw
let font = Tools.font

(***dessin***)
let message_name (v:Pomset.G.vertex) = Bmsc.message_name (Box.label v) 
let instance (v:Pomset.G.vertex) = Bmsc.instance (Box.label v) 
(* let associated_instance (v:Pomset.G.vertex) = Bmsc.associated_instance (Box.label v)  *)
let is_intl (v:Pomset.G.vertex) = Bmsc.is_intl (Box.label v) 
let is_send (v:Pomset.G.vertex) = Bmsc.is_send (Box.label v) 
let is_recv (v:Pomset.G.vertex) = Bmsc.is_recv (Box.label v) 
let pp v = Bmsc.pp (Box.label v)
let to_string v = Bmsc.to_string (Box.label v)
let same_message v1 v2 = Bmsc.same_message (Box.label v1) (Box.label v2)

let list_of_instances a =
  let classes = Classes.classes a in
    List.map instance (Classes.I.to_list classes) 

module T = Tools.Transitive(Pomset.G)
module L = Tools.Level(Pomset.G)


module Bmsc =
struct
  let string_of_alone e name =
    "\\gate*[c]{"^name^"}{"^(instance e)^"}\n"
      
  let string_of_futur pomset level v1 =
    let aux v2 =
      if instance v1 = instance v2 || same_message v1 v2
      then ""
      else "\\order{"^(instance v1)^"}{"^(instance v2)^"}["^string_of_int ((level v2) - (level v1))^"]\n"
    in
      List.fold_left (^) "" (List.map aux (Pomset.G.succ pomset v1))
	
  let string_of_intl pomset level e =
    string_of_alone e (pp e)
    ^string_of_futur pomset level e
      
  let string_of_recv pomset level e =
    let s =
      if List.filter (function e2 -> is_send e2 && message_name e2 = message_name e) (Pomset.G.pred pomset e) = []
      then 	(* si il est tout seul on trouve un message *)
	(*string_of_alone e ("?"^action_name e)*)
	"\\found"
 	^"[l]" (* ^ (if instance e < associated_instance e then "l" else "r") ^"]" *)
	^"{}{"^ message_name e ^"}"
	^"{"^ (instance e) ^"}\n"
      else ""  (* si il est associe a un envoi de message, on ne dessine rien, on s'en chargera quand
		  on traitera l'envoi associe *)
    in
      string_of_intl pomset level e ^ s ^string_of_futur pomset level e
	
  (* p est le pomset, h est la fonction de hauteur *)
  let string_of_send pomset level e1 =  
    let aux e2 = 
      if (* same_message e1 e2 *) instance e1 <> instance e2 then 
	"\\mess{"^(*message_name e1 ^*)"}"
	^"{"^ (instance e1) ^"}"
	^"{"^ (instance e2) ^"}"
	^"["^ string_of_int ((level e2) - (level e1)) ^"]\n"
      else ""
    in
    let s = List.fold_left (^) "" (List.map aux (Pomset.G.succ pomset e1)) in
      string_of_intl pomset level e1
      ^ (if s = "" 
	 then (* si il est tout seul, on a perdu un message *)
	   (* string_of_alone e1 ("!"^action_name e1) *)
	   "\\lost"
	   ^"[l]" (*^ (if instance e1 > associated_instance e1 then "l" else "r") ^"]"*)
	   ^"{}{"^ message_name e1 ^"}"
	   ^"{"^  (instance e1) ^"}\n"
	 else s)
      ^string_of_futur pomset level e1
	
  let string_of_level pomset level level_list = 
    List.fold_left (^) "" (List.map (string_of_send pomset level) (List.filter is_send level_list))
    ^List.fold_left (^) "" (List.map (string_of_intl pomset level) (List.filter is_intl level_list))
    ^List.fold_left (^) "" (List.map (string_of_recv pomset level) (List.filter is_recv level_list))
    ^"\\nextlevel\n"
      
  let string_of_graph pomset =
    let level = L.level pomset in
    let levels = L.decomposition level pomset in   
      List.fold_left (^) "" (List.map (string_of_level pomset level) levels)
	
  let string_of_instances e =
    let aux i =
      "\\declinst{"^ i ^"}{}"
      ^"{"^ i ^"}\n"
    in
    let s = ref "" in
      List.iter (function i -> s := !s^aux i) e;
      !s
	
  let c = ref 0 
  let fresh () = 
    incr c;
    "M_" ^ string_of_int !c

  let string_of_bmsc name b =
    "\\begin{msc}{$"^fresh ()^"$}\n"
    ^string_of_instances (List.sort compare (list_of_instances b))
    ^string_of_graph b 
    ^"\\end{msc}\n"
      
  let to_latex file b =
    "\\documentclass{article}\n"
    ^"\\pagestyle{empty}\n"
    ^"\\usepackage[active, tightpage]{preview}\n"
    ^"\\usepackage{msc}\n"
    ^"\\drawframe{no}"    
    ^"\\begin{document}\n"
    ^"\\begin{preview}\n"
    ^(string_of_bmsc file b)
    ^"\\end{preview}"
      
  (* TODO : gerer quand ca depasse 1 page *)
  let to_ps file pomset =
    let f = open_out (trash_dir^file^ext^".tex") 
    in
      Linearize.local_linearize pomset;
      output_string f (to_latex file (T.reduction pomset)); 
      close_out f;
      Tools.execute ("latex -interaction=nonstopmode -output-directory="^trash_dir^" "^trash_dir^file^ext^".tex >> "^trash_dir^"latex.out");
      Tools.execute ("dvips -q -o "^trash_dir^file^ext^".ps "^trash_dir^file^ext^".dvi")
	
  let make_img file pomset =
    assert (draw = "png");
    Tools.debug_endline ("Creating "^files_dir^file^ext^".png");
    to_ps file pomset;
    Tools.execute ("gs -dBATCH -sDEVICE=png16 -dTextAlphaBits=4 -r300 -dGraphicsAlphaBits=4 -dSAFER -q -dNOPAUSE -sOutputFile="^files_dir^file^ext^".png "^trash_dir^file^ext^".ps")
    (* Tools.execute ("convert "^files_dir^file^ext^".png "^files_dir^file^ext^".gif") *)

  let make_img_of_name file pomset =
    assert (draw = "png");
    let name = "temp" ^ string_of_int (Std.unique ()) in
      Tools.debug_endline ("Creating "^file);
      to_ps name pomset;
      Tools.execute ("gs -dBATCH -sDEVICE=png16 -dTextAlphaBits=4 -r300 -dGraphicsAlphaBits=4 -dSAFER -q -dNOPAUSE -sOutputFile="^file^" "^trash_dir^name^ext^".ps")
end

module Pgf =
struct
  (* todo : classe doit faire des trucs comme ca, mais j'y comprend plus rien ... *)
  (* c'est pas re-entrant mais on s'en fout a priori *)
  let y_ = Hashtbl.create 20
  let delta_y = 7
  let c = ref 0

  let y e =
    if Hashtbl.mem y_ (instance e)
    then ""
    else begin
      let coord = !c * delta_y in
	Hashtbl.add y_ (instance e) coord;
	incr c;
	Printf.sprintf "\\def\\%s{%i};\n" (instance e) coord
    end
      
  let clear () =
    Hashtbl.clear y_

  (* a lancer apres avoir fait tous les string_of_node *)
  let list_of_instances () =
     Hashtbl.fold (fun (i:string) (y:int) accu -> if List.mem i accu then accu else i :: accu) y_ []

  let name (e:Pomset.G.vertex) = (Box.num e:int)

  let string_of_node level e =
    Printf.sprintf  "%s\\node(%i) at (\\%s,%i) {%s};\n" (y e) (name e) (instance e) (-(level e)) (pp e)
      
  let string_of_level (level:Pomset.G.vertex -> int) level_list =
    List.fold_left (^) "" (List.map (string_of_node level) level_list)

  let string_of_nodes pomset =
    let level = L.level pomset in
    let levels = L.decomposition level pomset in
      List.fold_left (^) "" (List.map (string_of_level level) levels)

  let string_of_instance_i pomset (i:string) =
    let e_list = 
      List.fold_left (fun accu v -> if instance v = i then v :: accu else accu) [] (List.rev (Linearize.to_list pomset))
    in
      if e_list = [] 
      then ""
      else let l = List.fold_left (fun accu e -> Printf.sprintf "%s-- (%i) " accu (name e)) "" e_list in
	(  "\\node[fill=blue!50,draw,rounded corners,rectangle,minimum height=0.6cm,minimum width=1cm] "
	  ^ Printf.sprintf "(%s) at (\\%s,1){%s};\n\\draw[->] (%s) %s-- +(0,-1);\n" i (instance (List.hd e_list)) i i l )
				
  let string_of_instances pomset =
    List.fold_left (^) "" (List.map (string_of_instance_i pomset) (list_of_instances ()))

  let string_of_causalities pomset =
    let aux a b accu = 
      if instance a <> instance b 
      then begin
	if same_message a b 
	then Printf.sprintf "%s\\draw[->] (%i) -- (%i);\n" accu (name a) (name b)
	else Printf.sprintf "%s\\draw[dashed,->] (%i) -- (%i);\n" accu (name a) (name b)
      end else accu
    in
      Pomset.G.fold_edges aux pomset ""

  let to_latex pomset =
    clear ();
    let nodes = string_of_nodes pomset in
      "\\documentclass{article}\n"
      ^"\\pagestyle{empty}\n"
      ^"\\usepackage[active, tightpage]{preview}\n"
      ^"\\usepackage{pgf}\n"
      ^"\\usepackage{pgfcore}\n"
      ^"\\usepackage{pgfbaseimage}\n"
      ^"\\usepackage{pgfbaselayers}\n"
      ^"\\usepackage{pgfbasepatterns}\n"
      ^"\\usepackage{pgfbaseplot}\n"
      ^"\\usepackage{pgfbaseshapes}\n"
      ^"\\usepackage{pgfbasesnakes}\n"
      ^"\\usepackage{tikz}\n"
      ^"\\begin{document}\n"
      ^"\\begin{preview}\n"
      ^"\\begin{tikzpicture}[node distance=1cm]\n"
      ^nodes
      ^string_of_instances pomset
      ^string_of_causalities pomset
      ^"\\end{tikzpicture}\n"
      ^"\\end{preview}\n"
      ^"\\end{document}\n"

  (* TODO gerer quand ca depasse 1 page + recopie de code de Bmsc *)
  let to_ps file pomset = 
    let f = open_out (trash_dir^file^ext^".tex") 
    in
      Linearize.local_linearize pomset;
      output_string f (to_latex (T.reduction pomset)); 
      close_out f;
      Tools.execute ("latex -interaction=nonstopmode -output-directory="^trash_dir^" "^trash_dir^file^ext^".tex >> "^trash_dir^"latex.out");
      Tools.execute ("dvips -q -o "^trash_dir^file^ext^".ps "^trash_dir^file^ext^".dvi")

  let make_img file pomset =
    assert (draw = "png");
    Tools.debug_endline ("Creating "^files_dir^file^ext^".png");
    to_ps file pomset;
    Tools.execute ("gs -dBATCH -sDEVICE=png16 -dTextAlphaBits=4 -r300 -dGraphicsAlphaBits=4 -dSAFER -q -dNOPAUSE -sOutputFile="^files_dir^file^ext^".png "^trash_dir^file^ext^".ps")
   
  let make_img_of_name file pomset =
    assert (draw = "png");
    let name = "temp" ^ string_of_int (Std.unique ()) in
      Tools.debug_endline ("Creating "^file);
      to_ps name pomset;
      Tools.execute ("gs -dBATCH -sDEVICE=png16 -dTextAlphaBits=4 -r300 -dGraphicsAlphaBits=4 -dSAFER -q -dNOPAUSE -sOutputFile="^file^" "^trash_dir^name^ext^".ps")
end


module Graph =
struct
  let string_of_instance a i =
    "subgraph cluster_"^ i^" {\n"
    ^"style=filled;\ncolor=lightgrey;\nnode [style=filled, color=white];\n"
    ^Pomset.G.fold_vertex (fun v accu -> accu ^ if instance v = i then string_of_int (Box.num v) ^ "; " else "") a ""
    ^"label = \"process #"^ i^"\";\n}\n"
      
  let string_of_node n =
    string_of_int (Box.num n) ^ " [label=\"" ^ to_string n ^ "\"];\n"

  let string_of_edge n1 n2 =
    string_of_int (Box.num n1) ^ " -> " ^ string_of_int (Box.num n2) ^ ";\n"

  let to_dot a =
    "digraph G {\n"
    ^"graph [fontname=\""^font^"\"];\n"
    ^"node [fontname=\""^font^"\"];\n"
    ^"edge [fontname=\""^font^"\"];\n"
    ^List.fold_left (fun accu i -> accu ^ string_of_instance a i) "" (List.sort compare (list_of_instances a))
    ^Pomset.G.fold_vertex (fun n accu -> accu ^ string_of_node n) a ""
    ^Pomset.G.fold_edges (fun n1 n2  accu -> accu ^ string_of_edge n1 n2) a ""
    ^"}\n"

  let make_img file pomset =
    let f = open_out (trash_dir^file^ext^".dot") 
    in
      Tools.debug_endline ("Creating "^file);
      output_string f (to_dot pomset); 
      close_out f;
      Tools.execute (Tools.dot_path^"dot "^trash_dir^file^ext^".dot -T"^draw^" -o "^files_dir^file^ext^"."^draw)

  let make_img_of_name file pomset =
    let name = "temp" ^ string_of_int (Std.unique ()) in
    let f = open_out (trash_dir^name^".dot") 
    in
      Tools.debug_endline ("Creating "^file);
      output_string f (to_dot pomset); 
      close_out f;
      Tools.execute ("dot "^trash_dir^name^".dot -T"^draw^" -o "^file)
end

let img = ref "pgf"

let make_img file pomset = 
  Tools.info (Printf.sprintf "format: %s\n" !img);
  match !img with
      "graph" ->  Graph.make_img file pomset
    | "bmsc" -> Bmsc.make_img file pomset
    | "pgf" -> Pgf.make_img file pomset
    | s -> failwith (Printf.sprintf "%s: drawing format not supported." s)

let make_img_of_name file pomset = 
  Tools.info (Printf.sprintf "format: %s\n" !img);
  match !img with
      "graph" ->  Graph.make_img_of_name file pomset
    | "bmsc" -> Bmsc.make_img_of_name file pomset
    | "pgf" -> Pgf.make_img_of_name file pomset
    | s -> failwith (Printf.sprintf "%s: drawing format not supported." s)


 
