(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let min g =
  let l = ref [] in
    Pomset.G.iter_vertex (function v -> if Pomset.G.in_degree g v = 0 then l := v :: !l) g;
    !l

let choose l =
  if List.length l = 0 
  then raise (Invalid_argument "Unfold.choose")
  else List.nth l (Random.int (List.length l))

let instance (v:Pomset.G.vertex) = Bmsc.instance (Box.label v) 

let local_linearize g_init =
  let last = Hashtbl.create 99 in
  let g = Pomset.G.copy g_init in
  
    while Pomset.G.nb_vertex g > 0 do
      let next = choose (min g) in
	if Hashtbl.mem last (instance next) 
	then let old = Hashtbl.find last (instance next) in
	  Pomset.G.add_edge g_init old next;
	  Hashtbl.replace last (instance next) next;
	else Hashtbl.add last (instance next) next;
	Pomset.G.remove_vertex g next;
    done

 module T = Graph.Topological.Make(Pomset.G)

let to_action_list g =
  List.rev (T.fold (fun v accu -> (Box.label v) :: accu) g [])

let to_list g =
  List.rev (T.fold (fun v accu -> v :: accu) g [])
