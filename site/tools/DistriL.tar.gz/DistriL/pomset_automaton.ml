(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Base_types

let draw_ = ref true

module Arg =
struct
  type label = [`Case of string * bool_expr | `Nope] * string * Pomset.t
      
  type t = 
      { automaton : label Automaton.t;
	buffer : Pomset_trace.Model.t }
	
  let fresh () = "pomset" ^ string_of_int (Std.unique ())
    
  let from_trace (t:trace) = match t with
    | `Trace(a, `Case b) -> `Case(a,b), fresh (), Pomset.singleton (t:>Bmsc.label)
    | _ -> `Nope, fresh (), Pomset.singleton (t:>Bmsc.label)

  let combine_action model = function
    | `Nope -> model
    | action -> { model with buffer  = Pomset_trace.Model.combine_action model.buffer action }

  let from_automaton a = 
    { automaton = a; 
      buffer = Pomset_trace.Model.empty () }

  let to_automaton m = 
    if Pomset_trace.is_empty m.buffer
    then m.automaton
    else Automaton.concat m.automaton (Automaton.singleton (`Nope, fresh(), Pomset_trace.to_pomset m.buffer))

  let declare_edge (_,(_,name,pomset),_) =
    let dot_label =
      if !draw_
      then begin 
	Draw_pomset.make_img name pomset;
	"[ label=<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"0\"><TR><TD><IMG SRC=\""
	^Tools.files_dir^name^Pomset.ext^"."^Tools.draw
	^"\"/></TD></TR></TABLE>> style=\"setlinewidth(2),rounded\" ]" 
      end
      else "[label=\""^name^"\"]"
    in
    let shape = 
      if name = "" 
      then "node [ shape=rect width=0 height=0 label=\"\" ];"
      else "node [ shape=rect ];"
    in
      shape ^ name ^ dot_label ^ ";\n"
	
  let string_of_transition (n1,(c,name,pomset),n2) =
    if name <> "" then 
      declare_edge (n1,(c,name,pomset),n2)
      ^ "edge [ dir=none style=\"setlinewidth(2)\" ]; "
      ^string_of_int n1
      ^" -> "
      ^ name 
      ^";\nedge [ dir=normal arrowsize=2 style=\"setlinewidth(2)\" ]; "
      ^ name 
      ^" -> "
      ^string_of_int n2
      ^";\n"
    else
      "edge [ dir=normal style=\"setlinewidth(2)\" ]; "
      ^string_of_int n1
      ^" -> "
      ^string_of_int n2
      ^";\n" 
end

module Model = Automaton.Model(Arg)


(* todo : recopie de code de seq_automaton.ml *)

module Code =
struct
  type t = 
      { exec : Arg.label Automaton.exec;
	buffer : trace_io list }
	
  let is_finished code =  
    Automaton.is_finished code.exec
    && code.buffer =[]
    
  (* y a juste ca qui change *)
  let condition eval_bool t = 
    match (t:Arg.label) with
      | `Case (a,b),_,_ -> eval_bool a b 
      | `Nope ,_,_ -> true
    
  (* et beaucoup ca aussi *)
  let next (code:t) eval_bool = 
    if Automaton.has_undefined_agents code.exec
    then 
      let a, e = Automaton.declare_agent code.exec 
      in a, { code with exec = e }
    else
      if code.buffer <> []
      then 
	( (List.hd code.buffer :> action), { code with buffer = List.tl code.buffer } )
      else match Automaton.fireable (condition eval_bool) code.exec with
	| (_,(_,_,m),s) :: _ ->  
	    let lin = Linearize.to_action_list m in
	      assert (List.mem s code.exec.Automaton.automaton.Automaton.states);
	      (List.hd lin :> action), { exec = { code.exec with Automaton.current_state = s}; buffer = List.tl lin }
	| [] -> invalid_arg "next"
	    
  let agents (a:Arg.label) = match a with
    | _,_,p -> Pomset.G.fold_vertex (fun v accu -> agent_of_action ((Box.label v:>action)) :: accu) p []

   let make (a:Arg.t) =
    { exec = Automaton.make_exec agents (Arg.to_automaton a);
      buffer = [] }
      
  let to_string (a:t) = Model.to_string (Arg.from_automaton a.exec.Automaton.automaton)
end


module Big_step =
struct
  type t = Pomset.t Automaton.exec
  let is_finished c =
    Automaton.is_finished c
  
  let next (a:t) _ = 
    let f = Automaton.fireable (function x -> true) a in
    let _,p,s = List.nth f (Random.int (List.length f)) in
      (`Pomset p:>action), { a with Automaton.current_state = s }
 
   let agents (p:Pomset.t) = 
     Pomset.G.fold_vertex (fun v accu -> agent_of_action ((Box.label v:>action)) :: accu) p []

   let make (a:Arg.t) =
    Automaton.make_exec agents (Automaton.map  (function ((_,_,p):Arg.label) -> (p:Pomset.t))(Arg.to_automaton a))
end
