(* Copyright 2007 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of DistriL.

    DistriL is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DistriL is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DistriL; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Base_types
open Pomset


module Arg =
struct
  (* todo : le type n'est pas optimum : garder les maxs a chaque fois ca complique pour rien ... mais bon ca marche *)
  type t =
      { actions : (Bmsc.label, elt) Hashtbl.t;
	messages : ( string, elt Queue.t) Hashtbl.t;
	run : G.t }
	
  let empty () = 
    { actions = Hashtbl.create 99;
      messages = Hashtbl.create 99;
      run = empty () }
      
  let is_empty m = G.is_empty m.run 

  let empty_queue t =
    Hashtbl.fold (fun m q accu -> accu & Queue.is_empty q) t.messages true 

  let max_actions pomset =
    let m = Hashtbl.create 99 in
      List.iter 
	(function v -> if not (Hashtbl.mem m (Box.label v)) then Hashtbl.add m (Box.label v) v) 
	(List.rev (Linearize.to_list pomset));
      m
	
  let to_string m = 
    (* assert (safe m); *)
    Hashtbl.iter (fun a e -> Tools.debug (Printf.sprintf "%s <- %i\n" (action (a :> action)) (Box.num e))) m.actions; 
    to_string m.run
      
  let combine_action (model:t) (b:action) =
    let a = to_trace_io b in
      if a = `Nope 
      then model
      else 
	let e = Box.create a in
	  (* on ajoute l'evenement *)
	  G.add_vertex model.run e;
	  
	  (* on rajoute les causalites avec les actions qui sont dependantes *)
	  Hashtbl.iter (fun a' e' -> if !Composition.predicate a' a then G.add_edge model.run e' e) model.actions;
	  
	  (*on met a jour actions *)
	  if not (Hashtbl.mem model.actions a) 
	  then Hashtbl.add model.actions a e
	  else Hashtbl.replace model.actions a e;
	  
	  (* si c'est un envoi on le rajoute dans la queue de messages *)
	  if is_send e && not (Hashtbl.mem model.messages (message_name e))
	  then let q = Queue.create () in
	    Queue.add e q;
	    Hashtbl.add model.messages (message_name e) q 
	  else if is_send e
	  then Queue.add e (Hashtbl.find model.messages (message_name e)); 
	  
	  (* si c'est une reception, on rajoute une causalite avec le send correspondant *)
	  if is_recv e 
	  then (try G.add_edge model.run (Queue.take (Hashtbl.find model.messages (message_name e))) e 
		with _ -> failwith "the block is not communication closed");
	  { model with run = Transitive.reduction model.run }
	    
  let combine a b =
    if empty_queue a 
    then 
      let c = compose a.run b.run in
	{ actions = max_actions c;
	  messages = b.messages;
	  run = c } 
    else
      List.fold_left (fun accu a -> combine_action accu (a:>action)) a (Linearize.to_action_list b.run)	

  let output_model f p = 
    Draw_pomset.make_img_of_name f p.run
end
  
module Model = Trace.Model(Arg)

let is_empty = Arg.is_empty
let to_pomset m = m.Arg.run 

module Big_step = Trace.Model( 
struct
  type t = Pomset.t
  let empty = Pomset.empty
  let is_empty = Pomset.G.is_empty
  let combine_action pomset = function
    | `Pomset p -> Pomset.compose pomset p
    | _ -> pomset
  let combine = Pomset.compose
  let to_string = Pomset.to_string
  let output_model = Draw_pomset.make_img
end)
