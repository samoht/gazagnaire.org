(* Copyright 2005 Thomas Gazagnaire <thomas.gazagnaire@gmail.com> 
 
 This file is part of aDEX.

    aDEX is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    aDEX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with aDEX; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let infty = 100000000

open Tools

module Int =
struct
  type t = int
  let compare = Pervasives.compare
end
      
module Iset = Set.Make(Int)

module Imap = Map.Make(Int)

let union m1 m2 =
  Imap.fold (fun t n accu -> 
	      let ajout = 
		if Imap.mem t m1 then Imap.find t m1 else 0 
	      in
		Imap.add t (n+ajout) accu) m2 m1
let inter m1 m2 =
  Imap.fold (fun t n accu -> if Imap.mem t m2 then t :: accu else accu) m1 []

let elements m =
  Imap.fold (fun t n accu -> (t,n) :: accu) m []



module Event =
struct
  type t = 
      { id : int;
	loc : Iset.t; 
	mutable t : int Imap.t;
	mutable clock : int array }
  let compare e1 e2 = e2.id - e1.id
  let hash e = Hashtbl.hash e.id
  let equal e1 e2 = e1.id = e2.id
end
module G = Graph.Imperative.Digraph.Concrete(Event)

open Event

(* TODO : a optimiser avec un fold *)
let vleq v1 v2 =
  let b = ref true in
    for i = 0 to Array.length v1-1 do
      b := !b && v1.(i) <= v2.(i)
    done;
    !b


let vconcurrent v1 v2 =
  not (vleq v1 v2) && not (vleq v2 v1)


let leq m1 m2 =
  vleq m1.clock m2.clock

let compteur = ref 0
let create_primitive_event loc =
  incr compteur; 
  { id = !compteur; loc = Iset.singleton loc; clock = [||]; t = Imap.empty }




module Oper = Graph.Oper.I(G)
  
(* a priori on s'en fout de ce qu'il y a sur les arretes *)
(* si on veut bien faire faudrait faire des operations de fusion ...
   mais bon on s'en fout ... *)
let reduction g =
  let gc = Oper.transitive_closure g in
  let gcc = G.create () 
  and result = G.create ()
  in
    G.iter_vertex (G.add_vertex gcc) g;
    G.iter_vertex (G.add_vertex result) g;
    (* pour chaque arrete (u,w) de g, pour chaque (w,v) dans gc, on ajoute  (u,v) dans gcc *)
    G.iter_edges (fun u w -> G.iter_succ (fun v -> if w <> u && w <> v then G.add_edge gcc u v) gc w) g;
    (* on renvoit result = g - gcc *)
    G.iter_edges (fun u v -> if not (G.mem_edge gcc u v) then G.add_edge result u v) g;
    result


(***************************************)
(***************************************)
(* creation d'un run *)

let achoose a =
  a.(Random.int (Array.length a))

(* le run n'a pas de type et d'horloges vectorielles *)
let create_run_with_no_types_and_no_clocks n events =
  let processes = Array.create n None in
  let run = G.create () in
    
    for i = 0 to events do
      let l = Random.int n in
      let e = create_primitive_event l in
	(* on ajoute le nouvel event *)
	G.add_vertex run e;
	begin
	  match processes.(l) with
	    | None -> ()
	    | Some e' -> 
		(* on cree une causalite locale *)
		G.add_edge run e' e
	end;

	(* on rajoute des cousalites pour un certain nombre de dependances directes *)
	for j = 0 to Random.int alpha do
	  if j < beta then
	    match achoose processes with
	      | None -> ()
	      | Some e' -> G.add_edge run e' e
	done;

	(* on met a jour le dernier event sur le process considere *)    
	processes.(l) <- Some e;
    done;
    reduction run


let typage g =
  let t = ref 0 in
  let aux v1 v2 =
    if Iset.inter v1.loc v2.loc = Iset.empty 
    then begin
      v1.t <- union v1.t (Imap.add !t 1 Imap.empty);
      v2.t <- union v2.t (Imap.add !t 1 Imap.empty);
      incr t;
    end
  in
    G.iter_edges aux g


(**********************************)
(**********************************)
(* mise a jour des horloges *)
(* max(r,v) *)
let vmax r v =
  let n = Array.length r in
  let t = Array.create n infty in
    for i = 0 to n-1 do
      t.(i) <- max r.(i) v.(i)
    done;
    t

(* min(r,v) *)
let vmin r v =
  let n = Array.length r in
  let t = Array.create n infty in
    for i = 0 to n-1 do
      t.(i) <- min r.(i) v.(i)
    done;
    t

let veq r v =
  let b = ref true in
    for i = 0 to Array.length r-1 do
      b := !b && r.(i) = v.(i)
    done;
    !b

let vmax_aux n r v =
  for i = 0 to n-1 do
    r.(i) <- max r.(i) v.(i)
  done

let vmin_aux n r v =
  for i = 0 to n-1 do
    r.(i) <- min r.(i) v.(i)
  done

(* max(a | a \in liste) *)
let vmax_iter n liste =
  let r = Array.create n 0 in
  let rec aux = function
    | [] -> r
    | h :: t -> vmax_aux n r h; aux t
  in
    aux liste

let vmin_iter n liste =
  let r = Array.create n infty in
  let rec aux = function
    | [] -> r
    | h :: t -> vmin_aux n r h; aux t
  in
    aux liste



(* met a jours les horloges vectorielles dans la linearisation donnee *)
(* complexite : O(n^2 V) (n: nb process, V: nb elements dans la liste) *)
(* en fait on pourrait utiliser la meme astuce pour optimiser le clock_graph ... *)
(* L'ALGO SUIVANT NE MARCHE PAS *)
(* let clock_list n are_related run = 
   let incr e =
   Iset.iter (function i -> e.clock.(i) <- e.clock.(i) + 1) e.loc
   in
   let max = Array.create n None in
   let update e =
   print 20 (Printf.sprintf "on ajoute %i\n" e.id); 
   let res = ref [] in
   for i = 0 to n-1 do
   match max.(i) with
   | Some p when are_related p e -> 
   print 20 (Printf.sprintf "max.(%i) = %i\n" i p.id);
   print 20 (Printf.sprintf "%i -> %i\n" p.id e.id);  
   res := p.clock :: !res
   | Some p -> print 20 (Printf.sprintf "max.(%i) = %i\n" i p.id); ()
   | None -> print 20 (Printf.sprintf "max.(%i) = None\n" i); ()
   done;
   Iset.iter (function i -> print 20 (Printf.sprintf "max.(%i) <- %i\n" i e.id)) e.loc;
   Iset.iter (function i -> max.(i) <- Some e; 
   print 20 (Printf.sprintf "max.(%i) <> None : %b\n" i (max.(i) <> None))
   ) e.loc; 
   e.clock <- vmax_iter n !res;
   incr e;
   print 20 "\n"; 
   in
   List.iter update run *)

(* complexite : O(|run|^2) *)
(* ca flingue la complexite globale de l'algo ... *)
(* on peut dire qu'on est capable de couper pour eviter de prendre 2 fois un machin qui
   est sur un meme site, mais bon ...*)
(* Je n'ai vraiment pas reussi a faire mieux que ca ... et pourtant j'ai cherche ...*)
let clock_list n are_related run =
  let incr e =
    Iset.iter (function i -> e.clock.(i) <- e.clock.(i) + 1) e.loc
  in
  let update e =
    let related = List.filter (function f -> f.id <> e.id && are_related f e) run in
      e.clock <- vmax_iter n (List.map (function f -> f.clock) related);
      incr e;
  in
    List.iter update run

module T = Graph.Topological.Make(G)
let clock_event_graph n run =
  let incr e =
    Iset.iter (function i -> e.clock.(i) <- e.clock.(i) + 1) e.loc
  in
  let max = Array.create n None in
  let update_max e =
    Iset.iter (function i -> max.(i) <- Some e) e.loc
  in
  let update e =
    e.clock <- vmax_iter n (List.map (function e -> e.clock) (G.pred run e));
    incr e;
    update_max e;
  in
    T.iter update run


(* let clock_event_list n run = 
   clock_list n (fun e1 e2 -> Iset.inter e1.loc e2.loc <> Iset.empty) run *)


let create_run n l =
  let r = create_run_with_no_types_and_no_clocks n l in
    clock_event_graph n r;
    typage r;
    r




(***************************************)
(***************************************)
(* dessine *)
let string_of_int_array a =
  let soi i = if i = infty then "infty" else string_of_int i in
    if a = [||]
    then ""
    else    
      let s = ref ("[ " ^ soi a.(0)) in
	for i = 1 to Array.length a - 1 do
	  s := !s ^ "; " ^ soi a.(i)
	done;
	!s ^ " ]"

let string_of_int_set s =
  if s = Iset.empty 
  then "{ }"
  else "{ " ^ Iset.fold (fun i accu -> accu ^ string_of_int i ^ " ") s "" ^ "}"

let string_of_int_map m =
  if m = Imap.empty
  then "{ }"
  else "{" ^ Imap.fold (fun t n accu -> accu ^ " (" ^ string_of_int t ^ "," ^ string_of_int n ^ ")") m "" ^ " }"

(*let string_of_event e =
  Printf.sprintf "<tr><td>%i</td><td>%s</td><td>%s</td><td>%s</td></tr>" 
    e.id (string_of_int_set e.loc) (string_of_int_map e.t) (string_of_int_array e.clock) *)

let string_of_event e =
   Printf.sprintf "<tr><td>%s</td></tr>" (string_of_int_map e.t) 
     

let string_of_graph g name label =
  let string_of_node n = 
    name n ^ " [label=<<table BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\">" 
    ^ label n ^ "</table>>];\n"
  in
  let string_of_edge n1 n2 =
    name n1 ^ " -> " ^ name n2 ^ ";\n"
  in
    "digraph G {\nnode [shape=plaintext fontname=\"Sans\"]\n"
      (* ^List.fold_left (fun accu i -> accu ^ string_of_loc g i) "" (liste_to n)*)
    ^G.fold_vertex (fun n accu -> accu ^ string_of_node n) g ""
    ^G.fold_edges (fun n1 n2  accu -> accu ^ string_of_edge n1 n2) g ""
    ^"}\n"
  
let string_of_event_graph g =
  string_of_graph g (function e -> string_of_int e.id) string_of_event

(* l doit etre clockee *)
let event_graph_of_event_list n l =
  let g = G.create () in
  let add_edges i =
    List.iter (function v -> if leq i v && i.id <> v.id then G.add_edge g i v) l 
  in
    List.iter (G.add_vertex g) l;
    List.iter add_edges l;
    g

let draw_event_graph prio name g = 
  draw prio name (string_of_event_graph (reduction g))
    
let draw_event_list prio name n l =
  draw_event_graph prio name (event_graph_of_event_list n l)

let write_event_list prio name l =
  print prio  ("<" ^ string_of_int !iter ^ "> "^ name ^" : ");
  List.iter (function e -> print prio (string_of_int e.id^" ")) l;
  print prio "\n"
