(* Copyright 2005 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of aDEX.

    aDEX is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    aDEX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with aDEX; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Event
open Event

(* macros event *)
module Eset = Set.Make(Event)
module Ehtbl = Hashtbl.Make(Event)

type macro_event =
    { 
      num : int;
      mutable delta_moins : int array;
      mutable delta_plus : int array;
      mutable vus : int;
      mutable abstract : Eset.t; 
      mutable typage : int Imap.t; 
    }

module Macro =
struct
  type t = macro_event
  let equal m1 m2 = m1.num = m2.num
  let hash m = Hashtbl.hash m.num
end
module Mhtbl = Hashtbl.Make(Macro)


let list_to_set l =
  let rec aux accu = function
    | [] -> accu
    | h :: t -> aux (Iset.add h accu) t
  in
    aux Iset.empty l

let loc m =
  let l = ref [] in
    for i = 0 to Array.length m.delta_moins - 1 do
      if m.delta_moins.(i) < m.delta_plus.(i) 
      then l := i :: !l
    done;
    !l

let taille m =
  let rec aux = function
    | [] -> 0
    | i :: t -> m.delta_plus.(i) - m.delta_moins.(i) + (aux t)
  in
    aux (loc m)

let macro_to_event m =
  { id = m.num; loc = list_to_set (loc m);  clock = [||]; t = m.typage }

let event_to_macro e =
  let delta_plus = Array.copy e.clock in 
    { num = e.id;
      delta_plus = delta_plus;
      delta_moins = 
	begin
	  let d' = Array.create (Array.length delta_plus) infty in
	    Iset.iter (function i ->  d'.(i) <- delta_plus.(i) - 1) e.loc;
	    d'
	end;
      vus = 1;
      abstract = Eset.singleton e; 
      typage = e.t;
    }
 

(* est-ce que m1 est avant m2 ? *)
let is_before m1 m2 =
  let rec aux = function
    | [] -> false
    | i :: t when m1.delta_moins.(i) < m2.delta_plus.(i) -> true
    | i :: t when inter m1.typage m2.typage <> [] -> true 
    | i :: t -> aux t  
  in
    aux (loc m1)


let clock_event_list_with_macro n e2m run =
  clock_list n (fun e1 e2 -> is_before (e2m e1) (e2m e2)) run
  

let macro_list_to_event_list n ml =
  let e2m = Ehtbl.create 99 in
  let m2e = Mhtbl.create 99 in
  let aux m = 
    let e = macro_to_event m in
      Ehtbl.add e2m e m;
      Mhtbl.add m2e m e;
      e
  in
  let el = List.map aux ml in
    clock_event_list_with_macro n (Ehtbl.find e2m) el;
    (Ehtbl.find e2m, Mhtbl.find m2e, el) 




(**************************************)
(**************************************)
(* dessin *)
(*let string_of_macro m =
  "<tr><td COLSPAN=\"4\">id : "^string_of_int m.num^"</td></tr>"
  ^"<tr><td COLSPAN=\"4\">d- : "^string_of_int_array m.delta_moins^"</td></tr>"
  ^"<tr><td COLSPAN=\"4\">d+ : "^string_of_int_array m.delta_plus^"</td></tr>"
  ^"<tr><td COLSPAN=\"4\">vus : "^string_of_int m.vus
  ^" taille : "^string_of_int (taille m)^"</td></tr>"
  ^"<tr><td COLSPAN=\"4\">typage : "^string_of_int_map m.typage^"</td></tr>"
  ^Eset.fold (fun e accu ->  string_of_event e ^ accu ) m.abstract ""*)
let string_of_macro m =
  "<tr><td>"^string_of_int_map m.typage^"</td></tr>" 




let string_of_macro_list n ml =
  let string_of_macro_graph g e2m =
    string_of_graph g (function e -> string_of_int (e2m e).num) (function e -> string_of_macro (e2m e)) 
  in
  let e2m, m2e, el = macro_list_to_event_list n ml in
  let g = event_graph_of_event_list n el in
    string_of_macro_graph (reduction g) e2m
      
open Tools

let write_macro_list prio name l =
  print prio ("<" ^ string_of_int !iter ^ "> " ^ name ^ " : ");
  List.iter (function m -> print prio (string_of_int m.num^" ")) l;
  print prio "\n"

let draw_macro_list prio name n l =
  draw prio name (string_of_macro_list n l)


