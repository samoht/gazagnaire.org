(* Copyright 2005 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of aDEX.

    aDEX is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    aDEX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with aDEX; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let _ = 
  if Array.length Sys.argv <> 8
  then failwith "./main coeff_comm coeff_nb coeff_melange processes events random debug"

let debug = int_of_string Sys.argv.(7)
    
(* permet de regler la frequence avec laquelle les processus communiquent entre eux.
   plus c'est grand, moins c'est frequent *)
let alpha = int_of_string Sys.argv.(1)

(* permet de regler le nombre moyen de processus impliques dans une communication *)
let beta = int_of_string Sys.argv.(2)

(* permet de regler le melange de la simulation *)
let coeff_melange = int_of_string Sys.argv.(3)

let processes = int_of_string Sys.argv.(4)

let events = int_of_string Sys.argv.(5)

let print n s =
  if n < debug then
    begin
      print_string s;
      flush stdout
    end

let print_err = print (-1)

let iter = ref 0
let next_iter () = incr iter

let draw prio name what =
  if prio < debug then begin
    let n = "graph_"^name^"_"^string_of_int !iter in
    let f = open_out (n^".dot") in
      output_string f what;
      close_out f;
      (* print_string ("dot "^n^".dot -Tgif -o "^n^".gif\n")   *)
      ignore (Sys.command ("dot "^n^".dot -Tgif -o "^n^".gif"))  

  end
