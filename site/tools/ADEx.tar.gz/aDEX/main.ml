(* Copyright 2005 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of aDEX.

    aDEX is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    aDEX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with aDEX; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Tools
open Event
open Event
open Macro

(* quelques tests ... *)
let rec is_ordered = function
  | [] -> true
  | h :: t -> 
      List.fold_left (fun accu e -> 
			let b = not (is_before e h) in
			  if not b then print_err (Printf.sprintf "Pb : %i < %i\n" e.num h.num);
			  accu && b) 
	true t && is_ordered t


(*************************)
(*************************)
(* insertion *)

(* fusionne deux macros events *)
let fusion a b =
  if a.num <> b.num then begin
    print 15 (Printf.sprintf "fusion de %i et %i\n" a.num b.num);
    a.delta_moins <- vmin a.delta_moins b.delta_moins;
    a.delta_plus <- vmax a.delta_plus b.delta_plus;
    a.vus <- a.vus + b.vus;
    a.abstract <- Eset.union a.abstract b.abstract;
    a.typage <- union a.typage b.typage
  end

let rec find_before a = function
  | [] -> false
  | h::t when is_before h a -> true
  | h::t -> find_before a t

(* insere en virant les doublons, et en preservant -> *)
let rec insere_macro_list a = function
  | [] -> [a]
      (* | b :: t when b.num = a.num -> a :: t *)
      (* | b :: t when is_before a b && is_before b a -> print_err "Pb : insere_macro\n"; fusion a b; a :: t  *)
  | l when not (find_before a l) -> a :: l
  | h::t -> h :: insere_macro_list a t 

   
(* enleve de l les elements de rm *)
(* les deux listes sont classes par is_before croissant *)
(* TODO : c'est faux en general 
let rec remove_macro_list rm l =
  match rm,l with
    | [], l' -> l'
    | rm', [] -> []
    | h1::t1, h2::t2 when h1.num = h2.num -> 
	print 15 (Printf.sprintf "remove %i\n" h2.num); remove_macro_list t1 t2
    | h1::t1, h2::t2 when is_before h1 h2 -> 
	print 15 (Printf.sprintf "pas vu%i\n" h1.num); remove_macro_list t1 (h2::t2) 
    | h1::t1, h2::t2 when is_before h2 h1 -> 
   print 15 (Printf.sprintf "pas remove %i\n" h2.num); h2 :: remove_macro_list (h1::t1) t2 *)
let remove_macro_list rm l =
  let not_in_rm a = 
    not (List.exists (function b -> b.num = a.num) rm)
  in
    List.filter not_in_rm l



let rec merge_macro_list l1 l2 =
  match l1, l2 with
    | [],l -> l
    | l,[] -> l
	(*    | h1::t1, h2::t2 when h1.num = h2.num -> h1 :: merge_macro_list t1 t2 *)
    | h1::t1, h2::t2 when is_before h1 h2 -> h1 :: merge_macro_list t1 (h2::t2)
    | h1::t1, h2::t2 -> h2 :: merge_macro_list (h1::t1) t2


(* cherche tous les macros a l'interieur de qui a peut etre *)
(* let rec all_inside a = function
   | [] -> []
   | b ::t when a.num <> b.num && is_before b a && is_before a b -> 
   print 15 (Printf.sprintf "%i is inside of %i\n" a.num b.num) ; 
   b :: all_inside a t 
   | b :: t -> 
   all_inside a t *)


(* cherche tous les macro events qui ont le meme type que a *)
(* let all_same_type a macros = 
   let rec aux accu = function
   | [] -> accu
   | b ::t when a.num <> b.num && inter a.typage b.typage <> [] -> 
   print 15 (Printf.sprintf "%i has same type as %i\n" a.num b.num); 
   aux (b::accu) t
   | b :: t -> 
   aux accu t
   in
   aux [] macros *)

(* a <= b <= c*)
let is_between a b c =
  vleq a b && vleq b c

(* on va la jouer bourrin *)
let rec insere time n macro macro_list =
  print 10 "insere\n";
  if not (List.fold_left (fun acc e -> e.num <> macro.num && acc) true macro_list) then print_err "Pb : la liste contient deja le macro\n";
  if not (is_ordered macro_list) then print_err "Pb: liste pas triee\n"; 
  let e2m, m2e, event_list = macro_list_to_event_list n macro_list in

  let leq_iter a l = List.exists (function b -> leq (m2e a) (m2e b)) l in
  let geq_iter a l = List.exists (function b -> leq (m2e b) (m2e a)) l in
  let is_in a l = List.exists (function b -> a.num = b.num) l in
    
  (* on prend la fermeture transitive des elements plus petits que macro *)
  let weak_before = List.filter (function m -> is_before m macro) macro_list in
  let strong_before = List.filter (function m -> leq_iter m weak_before) macro_list in 
    
  (* on prend la fermeture transitive des elements plus grands que macro *)
  let weak_after = List.filter (function m -> is_before macro m) macro_list in
  let strong_after = List.filter (function m -> geq_iter m weak_after) macro_list in 
    
  let to_merge =
    List.filter (function m -> is_in m strong_after) strong_before
  in
    write_macro_list 10 "strong before" strong_before;
    write_macro_list 10 "strong after" strong_after;
    List.iter (fusion macro) to_merge;
    let l = ref [macro] in
      List.iter (function m -> l := insere_macro_list m !l) (remove_macro_list to_merge macro_list);
      if not (is_ordered !l) then print_err "Pb: liste pas triee\n"; 
      !l

(*let rec insere time n macro macro_list =
  print 10 "insere\n";
  if not (List.fold_left (fun acc e -> e.num <> macro.num && acc) true macro_list) then print_err "Pb : la liste contient deja le macro\n";
  if not (is_ordered macro_list) then print_err "Pb: liste pas triee\n"; 
  let e2m, m2e, event_list = macro_list_to_event_list n macro_list in
    
  (* on prend la fermeture transitive des elements plus petits que macro *)
  let weak_before = List.filter (function m -> is_before m macro) macro_list in
  let max_before = vmax_iter n (List.map (function m -> (m2e m).clock) weak_before) in
  let strong_before = List.filter (function m -> vleq (m2e m).clock max_before) macro_list in 
  let not_strong_before = List.filter (function m -> not (vleq (m2e m).clock max_before)) macro_list in 
    
  (* on prend la fermeture transitive des elements plus grands que macro *)
  let weak_after = List.filter (function m -> is_before macro m) macro_list in
  let max_after = vmax_iter n (List.map (function m -> (m2e m).clock) weak_after) in
  let strong_after = List.filter (function m -> vleq (m2e m).clock max_after) macro_list in 
  let not_strong_after = List.filter (function m -> not (vleq (m2e m).clock max_after)) macro_list in 
    
  let to_merge =
    (*    let merge = ref [] in
	  let aux a = 
	  let l = List.filter (function m -> 
	  let b = vleq (m2e m).clock max_after && vleq (m2e a).clock (m2e m).clock && vleq (m2e a).clock max_after in
	  print 10 (Printf.sprintf "%i:%s est entre %i:%s et %s : %b\n" 
	  m.num (string_of_int_array (m2e m).clock) 
	  a.num (string_of_int_array (m2e a).clock) 
					   (string_of_int_array max_after) b); 
	  b) weak_before in
	  List.iter (function m -> merge := insere_macro_list m !merge) l;*)
    List.filter (function m -> vleq max_after (m2e m).clock) strong_before
    @ List.filter (function m -> vleq (m2e m).clock max_before) strong_after      (*in
	List.iter aux weak_before;
	!merge (*      write_macro_list 10 ("merge "^string_of_int a.id) l; l *) *)
  in

    write_macro_list 10 "weak before" weak_before;
    print 20 ("max_before :"^string_of_int_array max_before^"\n"); 
    write_macro_list 10 "strong before" strong_before;
    write_macro_list 10 "not strong before" not_strong_before;
    
    write_macro_list 10 "weak after" weak_after;
    print 20 ("max_after :"^string_of_int_array max_after^"\n");
    write_macro_list 10 "strong after" strong_after;
    draw_event_list 10 "events" n event_list;

(*  if weak_after <> [] && weak_before <> [] 
    then let to_merge = List.filter (function m -> vleq max_after (m2e m).clock && vleq (m2e m).clock max_before) macro_list in *)
    List.iter (fusion macro) to_merge;  
    write_macro_list 10 "to_merge" to_merge;
    let l = remove_macro_list to_merge macro_list in 
    let l' = ref [macro] in
      List.iter (function m -> l' := insere_macro_list m !l') l;
      if not (is_ordered !l') then print_err "Pb: liste pas triee\n"; 
      !l'*)
(* else strong_before @ (macro :: not_strong_before) *)
    (* if List.length to_merge = 0 
       then begin
       let macro_before = List.filter (function m -> vleq (m2e m).clock max_before) macro_list 
       and macro_not_before = List.filter (function m -> not (vleq (m2e m).clock max_before)) macro_list 
       in
       write_macro_list 10 "macro_before" macro_before;
       write_macro_list 10 "macro_not_before" macro_not_before;
       if time > 5 then print_err ("Nb  :"^string_of_int time^"\n");
       macro_before @ (macro :: macro_not_before)
       end 
       else insere (time+1) n macro (remove_macro_list to_merge macro_list) *)
    
      
(*    (* TODO : on peut optimiser si on n'a rien a merge *)
      write_macro_list 10 "to_merge" to_merge;
      
      
      let macro_list2 = remove_macro_list to_merge macro_list in
      
      if List.length to_merge >= 1  
      then (* si on doit merger au moins 2 events avec macro *)
      let min = vmin_iter n [min_after; max_before] (*List.map (function m -> (m2e m).clock) to_merge*) in
      let max = vmax_iter n [min_after; max_before] (*List.map (function m -> (m2e m).clock) to_merge*) in
      print 10 ("min : "^string_of_int_array min^"\n");
      print 10 ("max : "^string_of_int_array max^"\n");
      let macro_concurrent = 
      List.filter (function m -> vconcurrent (m2e m).clock min && vconcurrent (m2e m).clock max) macro_list2
      in
      List.iter (function e -> print 50 (string_of_event e^"\n")) (List.map m2e macro_concurrent); 
      let macro_before = 
      List.filter (function m -> vleq (m2e m).clock max) macro_list2
      in
      let macro_after =
      List.filter (function m -> vleq min (m2e m).clock) macro_list2
      in
      write_macro_list 10 "concurrent" macro_concurrent;
      write_macro_list 10 "before" macro_before;
      write_macro_list 10 "after" macro_after;
      macro_before @ macro_concurrent @ [macro] @ macro_after
      else
      insere_macro_list macro macro_list2
*)    


(****************************************)
(****************************************)
(* extraction *)

let is_minimal m dmin =
  let rec aux = function
    | [] -> true
    | i :: t when m.delta_moins.(i) <> dmin.(i) -> false
    | i :: t -> aux t
  in
    aux (loc m)

let is_convex m =
  taille m = m.vus

let is_type_complete m beta =
  Imap.fold (fun k v accu -> accu && v = beta k) m.typage true


let update_min m dmin = 
  List.iter (function i -> dmin.(i) <- m.delta_plus.(i)) (loc m)

let update_delta m delta =
  let n = Array.length delta in
  let d = vmax_iter n (List.map (function i -> delta.(i)) (loc m)) in
    List.iter (function j -> d.(j) <- d.(j) + 1) (loc m);    
    List.iter (function i -> delta.(i) <- d) (loc m)
	       
    
let one_loc m =
  match loc m with
    | [] -> failwith "one_loc"
    | h :: t -> h

(* modification de dmin et delta *)
let rec extraire macro_list dmin delta beta product =
  let rec aux to_remove to_product = function
    | [] -> List.rev to_remove, List.rev to_product
    | m :: t when is_minimal m dmin && is_convex m && is_type_complete m beta -> 
	update_min m dmin;
	update_delta m delta;
	let e = macro_to_event m in
	  e.clock <- Array.copy delta.(one_loc m);
	  aux (m::to_remove) ((e,m)::to_product) t
    | m :: t -> 
	aux to_remove to_product t
  in
  let to_remove, to_product = aux [] [] macro_list in
    product to_product;
    let ml = remove_macro_list to_remove macro_list in
      if to_product <> [] 
      then extraire ml dmin delta beta product 
      else ml
    


(********************************)
(********************************)
(* main *)

(* melange la liste li *)
let melange li =
  let l = ref li in
  let rl = ref [] in
    while !l <> [] do
      let e = List.nth !l (Random.int (List.length !l)) in
	l := List.filter ((<>) e) !l;
	rl := e :: !rl;
    done;
    !rl

let melange_un_peu li =
  if coeff_melange < 0 then melange li
  else
    let a = Array.of_list li in
      for i = 0 to coeff_melange do
	let n = Random.int (Array.length a) in
	  if n > 0 then 
	    let tmp = a.(n) in
	      a.(n) <- a.(n-1);
	      a.(n-1) <- tmp
      done;
      List.rev (Array.to_list a)

(* run a ete clocke et typee *)
let abstrait n beta run product =
  let l = melange_un_peu (G.fold_vertex (fun v accu -> v :: accu) run []) in
  let delta_min = Array.create n 0 in
  let delta = Array.create_matrix n n 0 in
  
  let main macro_list e =
    next_iter ();
    print 0 (Printf.sprintf "<%i> Selection de l'event : (%i)\n" !iter e.id); 
    let m = event_to_macro e in
    let macro_list' = insere 1 n m macro_list in
    let out = extraire macro_list' delta_min delta beta product in
      write_macro_list 15 "macro" out; 
      draw_macro_list 10 "macro" n out; 
      out
  in
    List.fold_left main [] l
    

(* on pretty-print le resultat *)
let pretty_draw_em_list name n eml =
  let string_of_macro_graph g e2m =
    string_of_graph g (function e -> string_of_int (e2m e).num) (function e -> string_of_event e ^ string_of_macro (e2m e)) 
  in
  let el = List.map (function (e,m) -> e) eml in
  let e2m e = List.assoc e eml in 
  let g = event_graph_of_event_list n el in
    draw 0 name (string_of_macro_graph (reduction g) e2m)

let _ =
  (*Random.self_init (); *)
  Random.init (int_of_string Sys.argv.(6));
  let beta _ = 2
  and received = ref []
  in
  let product l =  
    if l <> [] then begin
      received := !received @ l;
      write_macro_list 0 "recu" (List.map (function (e,m) -> m) l); 
      (* pretty_draw_em_list "received" processes !received; *)
    end
  in
    print 0 "On genere une execution aleatoire\n";
  let run = create_run processes events in
    print 0 "On dessine l'execution\n";
    draw_event_graph 0 "run" run;
    print 0 "On abstrait en simulant l'execution calculee\n";
    
    let memory = abstrait processes beta run product in
      print 0 (Printf.sprintf "%i macro-events ont ete recus\n" (List.length !received));
      print 0 "On dessine l'execution abstraite\n";
      draw_event_list 0 "abstract" processes (List.map (function (e,m) -> e) !received);
      pretty_draw_em_list "abstract_expanded" processes !received; 
      if memory <> []
      then begin
	print_err "Pb: la memoire n'est pas vide\n";
	draw_macro_list (-1) "memory" processes memory;
      end

(* let _ = 
   for i = 0 to (int_of_string Sys.argv.(6)) do
   print (-1) (Printf.sprintf "%i : %s\n");
*)
