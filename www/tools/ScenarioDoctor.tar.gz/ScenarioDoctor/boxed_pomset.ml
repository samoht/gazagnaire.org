(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

module T = Graph.Oper.I(Pomset.G)
module P = Tools.Project(Pomset.G)
module R = Tools.Transitive(Pomset.G)

type elt = Pomset.elt

let default () = Box.create (Bmsc.Intl (0,""))

type classes = Classes.t

type t = 
    { 
      input : elt array;
      msc : Pomset.t; 
      output :elt array;
    }

let create_port classes =
  Array.make (Classes.size classes) (default ())

(* attention, on modifie b *)
let box classes b =
  let input = create_port classes in
  let output = create_port classes in
    for classe = 0 to Array.length input - 1 do
      let i = Classes.dummy classes classe in
      let o = Classes.dummy classes classe in
	Pomset.G.add_vertex b i;
	Pomset.G.add_vertex b o;

	Pomset.G.iter_vertex (function v -> if Classes.classe classes v = classe 
			      then begin
				if v <> i then Pomset.G.add_edge b i v;
				if v <> o then Pomset.G.add_edge b v o;
			      end) b;
	input.(classe) <- i;
	output.(classe) <-o;
    done;
    {
      input = input;
      output = output;
      msc = R.reduction b
    }

let unbox b =
  let b' = Pomset.G.copy b.msc in  
    Array.iter (Pomset.G.remove_vertex b') b.input;
    Array.iter (Pomset.G.remove_vertex b') b.output;
    b'

let semi_unbox b =
  let b' = Pomset.G.copy b.msc in  
    Array.iter (Pomset.G.remove_vertex b') b.output;
    b'

let empty () = box (Classes.create ()) (Pomset.empty ())

let compose b1 b2 =
  if b1 = empty () then b2
  else begin
    let assoc, msc = Pomset.compose_with_assoc b1.msc b2.msc in
    let link pred succ = 
      List.iter (function p -> List.iter (function s -> Pomset.G.add_edge msc p s) succ) pred
    in
      Array.iter (function v -> 
		    link (Pomset.G.pred msc v) (Pomset.G.succ msc v);
		    Pomset.G.remove_vertex msc v;
		 ) b1.output;

      Array.iter (function v -> 
		    link (Pomset.G.pred msc (assoc v)) (Pomset.G.succ msc (assoc v));
		    Pomset.G.remove_vertex msc (assoc v);
		 ) b2.input;
      
      { 
	input = b1.input;
	output = Array.map assoc b2.output;
	msc = R.reduction msc;
      }
  end

let in_port port v =
  Array.fold_left (fun accu v' -> accu && v <> v') true port 

let project is_proj b =
 { 
   input = b.input;
   output = b.output;
   msc = P.project (function v -> not (in_port b.input v) || not (in_port b.output v) || is_proj v) b.msc;
 }

let equal b1 b2 =
  Isomorphism.equal b1.msc b2.msc 

let prefix_of b1 b2 =
  Isomorphism.prefix_of b1.msc (semi_unbox b2) 


let hash b =
  Isomorphism.hash b.msc

let size b =
 (Pomset.G.nb_vertex b.msc) - 2*(Array.length b.input)

let to_file f b = Pomset.to_file f b.msc

let from_file f =
  let b = Pomset.from_file f in
  let c = Classes.classes b in
    box c b

let make_img f b =
  Pomset_automaton.P.make_img f b.msc 
    (* (P.project (function v -> not (Pomset.G.mem_vertex i v) && not (Pomset.G.mem_vertex o v)) b) *)

let to_file f b =
  Pomset_automaton.P.to_file f b.msc
    (* (P.project (function v -> not (Pomset.G.mem_vertex i v) && not (Pomset.G.mem_vertex o v)) b) *)

let ext = Pomset.ext
