(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

module Topo = 
Graph.Topological.Make(Pomset.G)

(* optimisable si y beaucoup d'instances ...*)
let trie_par_instance c g =
  let psi = Array.create (Classes.size c) [] in
    Topo.iter (function v -> let i = Classes.classe c v in psi.(i) <- v :: psi.(i)) g;
    Array.map List.rev psi
      
(* est ce que le mot l1 est prefixe de l2 ? *)
let rec word_prefix l1 l2 =
  match l1, l2 with
    | [], _ -> true
    | h1 :: t1, h2 :: t2 when Box.label h1 = Box.label h2 -> word_prefix t1 t2
    | _,[] -> false
    | _,_ -> false
	
let make_psi l1 l2 =
  let psi = Hashtbl.create 99 in
  let rec aux = function
    | h1 :: t1, h2 :: t2 -> Hashtbl.add psi h2 h1; aux (t1,t2)
    | _ -> () 
  in
    assert (Array.length l2 >= Array.length l1);
    for i = 0 to Array.length l2 - 1 do
      aux (l1.(i), l2.(i))
    done;
    Hashtbl.find psi
      
(* v1,v2 \in p1 \imply psi(v1),psi(v2) \in p2 *)
let subset psi p1 p2 =
(* Pomset.G.fold_edges (fun v1 v2 accu -> accu && Pomset.G.mem_edge p2 (psi v1) (psi v2)) p2 true *)
  Pomset.G.fold_vertex 
    (fun v1 accu1 ->
	accu1 && Pomset.G.fold_vertex 
	  (fun v2 accu2 -> accu2 && 
	     let mem_edge_p2 = Pomset.G.mem_edge p2 v1 v2 in
	       mem_edge_p2 || ( not mem_edge_p2 && not (Pomset.G.mem_edge p1 (psi v1) (psi v2)) )
	  ) p2 true
    ) p2 true


(* v1,v2 \in p1 \equiv psi(v1),psi(v2) \in p2 *)
(* let prefix psi p1 p2 =
   let b = ref true in
   Pomset.G.iter_vertex (function v1 ->
   Pomset.G.iter_vertex ( function v2 -> 
   b := !b 
   && (( Pomset.G.mem_edge p1 v1 v2 && Pomset.G.mem_edge p2 (psi v1) (psi v2) ) 
   || ( not (Pomset.G.mem_edge p1 v1 v2) && not (Pomset.G.mem_edge p2 (psi v1) (psi v2))))
   ) p1 
			) p1;
   !b
*)     

let verify classes_exec prop classes_obs =
  Array.length classes_obs >= Array.length classes_exec &&
    let b = ref true in
      for i = 0 to Array.length classes_obs - 1 do
	b := !b && prop classes_exec.(i) classes_obs.(i)
      done;
      !b

(* est-ce que p est prefix de o ? (on peut oublier des causalites) *)
let prefix_of = function obs ->
  let o = Classes.classes obs in
  let classes_obs = trie_par_instance o obs in
    function exec ->
      let e = Classes.classes exec in
	Classes.subset e o &&
	  let classes_exec = trie_par_instance o exec
	  in
	    verify classes_exec word_prefix classes_obs 
	    && let psi = make_psi classes_obs classes_exec in 
	      subset psi obs exec
	    
let equal b1 b2 = 
  let c1 = Classes.classes b1 in
  let c2 = Classes.classes b2 in
    Classes.equal c1 c2 &&
      let classes1 = trie_par_instance c1 b1
      and classes2 = trie_par_instance c1 b2
      in
	Pomset.G.nb_vertex b1 = Pomset.G.nb_vertex b2
	  && Pomset.G.nb_edges b1 = Pomset.G.nb_edges b2
	  && verify classes1 word_prefix classes2 
	  && let psi = make_psi classes1 classes2 in
	    subset psi b1 b2
	  
   
let hash p =  
  (Pomset.G.nb_vertex p)*101 + (Pomset.G.nb_edges p)*13



