(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

open Automaton

let trash_dir = Tools.trash_dir
let files_dir = Tools.files_dir
let ext = ".bhmsc"

module P = 
struct
  include Boxed_pomset
end

module T =
struct
  type t = Boxed_pomset.t edge Box.t
  let compare e1 e2 = compare (Box.num e1) (Box.num e2)
  let default = Box.create { name = "" ; msc = Boxed_pomset.empty () }
end

let create_edge name msc =
  Box.create { name = name; msc = msc }

let compose e1 e2 =
  { 
    name = e1.name ^ "." ^ e2.name ;
    msc = Pomset_automaton.compose e1.msc e2.msc
  }
  
module G = Graph.Imperative.Digraph.ConcreteLabeled(Automaton.State)(T)

let classes a =
  let c = Classes.create () in
    Pomset_automaton.G.iter_edges_e (function (n1,e,n2) -> Classes.update c (Box.label e).Pomset_automaton.msc) a;
    c

let of_pomset_automaton a =
  let g = G.create () in
  let c = classes a in
    Pomset_automaton.G.iter_vertex (G.add_vertex g) a;
    Pomset_automaton.G.iter_edges_e 
      (function (n1,e,n2) -> 
	 let name = (Box.label e).Pomset_automaton.name in
	 let msc = Boxed_pomset.box c (Box.label e).Pomset_automaton.msc in
	   G.add_edge_e g (n1, create_edge name msc , n2)
      ) a;
    g

let boxed_classes a =
  let c = Classes.create () in
    G.iter_edges_e (function (n1,e,n2) -> Classes.update c (Box.label e).Pomset_automaton.msc.Boxed_pomset.msc) a;
    c

let project is_proj a =
  let g = G.create () in
  let aux (src,e,dst) =
    let name = (Box.label e).Pomset_automaton.name in
    let msc = Boxed_pomset.project is_proj (Box.label e).Pomset_automaton.msc in
    let e' = create_edge name msc in      
      G.add_edge_e g (src,e',dst)
  in
    G.iter_vertex (G.add_vertex g) a;
    G.iter_edges_e aux a;
    g

let declare_edge (src,edge,dst) = 
  let b = Box.label edge in
  let box = b.Automaton.msc in
  let b' = Pomset_automaton.create_edge b.Automaton.name box.Boxed_pomset.msc in
    Box.renum b' (Box.num edge);
    Pomset_automaton.declare_edge (src, b', dst)

let dot_of a =
  "digraph{\n"
  ^G.fold_edges_e (fun e s -> s ^ declare_edge e)  a ""
  ^G.fold_vertex  (fun v s -> s ^ Pomset_automaton.declare_node v) a ""
  ^G.fold_edges_e (fun e s -> s ^ Pomset_automaton.string_of_edge e) a ""
  ^"}\n"

let make_png file hmsc =
  let f = open_out (trash_dir ^ file ^ ext ^ ".dot")
  in
    output_string f (dot_of hmsc);
    close_out f;
    Tools.print ("Creating " ^ files_dir ^ file ^ ext ^".png");
    Tools.execute (Printf.sprintf "dot -Tpng -o %s%s%s.png %s%s%s.dot" files_dir file ext trash_dir file ext) 
