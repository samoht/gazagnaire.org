type token =
  | INT of (int)
  | STRING of (string)
  | CROC_O
  | CROC_F
  | COMMA
  | SEMICOLON
  | EOF
  | SEND
  | RECV
  | INTL
  | SHARP

open Parsing;;
# 6 "depend_parser.mly"
  let parse_error s = (* Called by the parser function on error *)
    (* pour bien faire il faudrait un File %s, line %i: syntax error *)
    Printf.printf "dep : %s on characters %i-%i\n" s (symbol_start ()) (symbol_end ());
    flush stdout
# 21 "depend_parser.ml"
let yytransl_const = [|
  259 (* CROC_O *);
  260 (* CROC_F *);
  261 (* COMMA *);
  262 (* SEMICOLON *);
    0 (* EOF *);
  263 (* SEND *);
  264 (* RECV *);
  265 (* INTL *);
  266 (* SHARP *);
    0|]

let yytransl_block = [|
  257 (* INT *);
  258 (* STRING *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\001\000\002\000\003\000\003\000\003\000\000\000"

let yylen = "\002\000\
\002\000\003\000\001\000\005\000\004\000\004\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\003\000\000\000\008\000\000\000\000\000\
\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\
\000\000\002\000\000\000\000\000\007\000\000\000\005\000\006\000\
\004\000"

let yydgoto = "\002\000\
\006\000\007\000\011\000"

let yysindex = "\001\000\
\253\254\000\000\001\255\000\000\002\255\000\000\253\254\004\255\
\010\255\011\255\008\255\253\254\000\000\012\255\013\255\014\255\
\001\255\000\000\016\255\017\255\000\000\015\255\000\000\000\000\
\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000"

let yygindex = "\000\000\
\250\255\000\000\003\000"

let yytablesize = 20
let yytable = "\003\000\
\013\000\001\000\004\000\012\000\014\000\018\000\005\000\008\000\
\009\000\010\000\015\000\016\000\017\000\019\000\020\000\021\000\
\023\000\024\000\025\000\022\000"

let yycheck = "\003\001\
\007\000\001\000\006\001\002\001\001\001\012\000\010\001\007\001\
\008\001\009\001\001\001\001\001\005\001\002\001\002\001\002\001\
\001\001\001\001\004\001\017\000"

let yynames_const = "\
  CROC_O\000\
  CROC_F\000\
  COMMA\000\
  SEMICOLON\000\
  EOF\000\
  SEND\000\
  RECV\000\
  INTL\000\
  SHARP\000\
  "

let yynames_block = "\
  INT\000\
  STRING\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'depend) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 :  (Bmsc.t * Bmsc.t) list ) in
    Obj.repr(
# 18 "depend_parser.mly"
               ( _1 :: _2 )
# 105 "depend_parser.ml"
               :  (Bmsc.t * Bmsc.t) list ))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 :  (Bmsc.t * Bmsc.t) list ) in
    Obj.repr(
# 19 "depend_parser.mly"
                     ( _3 )
# 113 "depend_parser.ml"
               :  (Bmsc.t * Bmsc.t) list ))
; (fun __caml_parser_env ->
    Obj.repr(
# 20 "depend_parser.mly"
            ( [] )
# 119 "depend_parser.ml"
               :  (Bmsc.t * Bmsc.t) list ))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'label) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'label) in
    Obj.repr(
# 24 "depend_parser.mly"
                                ( (_2, _4) )
# 127 "depend_parser.ml"
               : 'depend))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 28 "depend_parser.mly"
                      ( Bmsc.Send (_2, _3, _4) )
# 136 "depend_parser.ml"
               : 'label))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 29 "depend_parser.mly"
                      ( Bmsc.Recv (_2, _3, _4) )
# 145 "depend_parser.ml"
               : 'label))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 30 "depend_parser.mly"
                  ( Bmsc.Intl (_2, _3) )
# 153 "depend_parser.ml"
               : 'label))
(* Entry input *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let input (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf :  (Bmsc.t * Bmsc.t) list )
