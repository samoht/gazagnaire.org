(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

(* la partie commune a tous les 
pomsets *)
type t = 
  | Send of int * string * int 
  | Recv of int * string * int
  | Intl of int * string

let instance = function
  | Send (i,_,_) -> i
  | Recv (i,_,_) -> i
  | Intl (i,_) -> i
 
let action_name = function
  | Send (_,m,_) -> m
  | Recv (_,m,_) -> m
  | Intl (_,m) -> m

let is_send = function 
  | Send _ -> true
  | _ -> false
      
let is_recv = function
  | Recv _ -> true
  | _ -> false
      
let is_intl = function
  | Intl _ -> true
  | _ -> false	

let to_string = function
  | Send (i,m,j) -> Printf.sprintf "send %i %s %i" i m j
  | Recv (i,m,j) -> Printf.sprintf "recv %i %s %i" i m j
  | Intl (i,m) -> Printf.sprintf "intl %i %s" i m

let pp = function
  | Send (i,m,j) -> Printf.sprintf "%d!%d(%s)" i j m
  | Recv (i,m,j) -> Printf.sprintf "%d?%d(%s)" i j m
  | Intl (i,m) -> Printf.sprintf "%d(%s)" i m

let same_message l1 l2 = 
  match l1, l2 with
    | Send (i,m,j), Recv (k,n,l) -> i=l && m=n && j=k
    | Recv (k,n,l), Send (i,m,j) -> i=l && m=n && j=k
    | _,_ -> false

let associated_instance = function
  | Send (_,_,i) -> i
  | Recv (_,_,i) -> i
  | Intl (_,_) -> failwith "Bmsc.associate_instance"
