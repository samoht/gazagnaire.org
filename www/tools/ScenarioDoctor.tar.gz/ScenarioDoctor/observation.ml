(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = Tools.files_dir
let ext = ".obs"

let parse file =
  let s = open_in (files_dir^file^ext)
  in
  let obs = (Str.split (Str.regexp " ") (input_line s)) in
    List.iter Tools.print obs;
    function v ->
      List.mem (Bmsc.pp (Box.label v)) obs

(*  function v ->  
    Bmsc.action_name (Pomset.Bmsc.L.V.label v) = "a" 
    || Bmsc.action_name (Pomset.Bmsc.L.V.label v) = "b" *)


(* let count v accu = 1 + accu
   let size b = NaccPomset.Bmsc.G.fold_vertex count b 0 *)
(* module Proj = Graph_tools.Project(NaccPomset.Bmsc.G)
   
   let make is_observable k a =
   let h = Unfold.Hmsc.random_bounded a k in
   Draw.Bmsc.make_png "all" h; 
   Proj.project is_observable h  *)
