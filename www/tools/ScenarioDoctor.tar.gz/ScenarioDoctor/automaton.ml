(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

type state =
    {     
      start : bool;
      final : bool; 
    }
      
let create_state s f = 
  { 
    start = s; 
    final = f 
  }
    
let is_start v = v.start
let is_final v = v.final

module State = 
struct
  type t = state Box.t
  let compare e1 e2 = compare (Box.num e1) (Box.num e2)
  let equal e1 e2 = (Box.num e1) = (Box.num e2)
  let hash e1 = Hashtbl.hash (Box.num e1)
end

let normalize_edges iter i0 a =
  let c = ref i0 in
  let rename (_,e,_) =
    Box.renum e !c;
    incr c;
  in
    iter rename a 
 

module Remove (G : Graph.Sig.I) =
struct
  let non_coaccessible_states is_final a =
    let final = 
      G.fold_vertex (fun v accu -> if is_final v then v :: accu else accu) a [] 
    in
    let out = G.create () in
    let seen = Hashtbl.create 99 in
    let rec aux v =
      if not (Hashtbl.mem seen v) 
      then begin
	Hashtbl.add seen v true;
	G.add_vertex out v;
	G.iter_pred_e (G.add_edge_e out) a v;
	G.iter_pred aux a v;
      end
    in
      List.iter aux final;
      out 
end

type 'a edge = 
    { name : string ; msc : 'a }


(* module StringTransition =
   struct
   type t = string Box.t
   let compare e1 e2 = compare (Box.num e1) (Box.num e2)
   let default = Box.create ""
   end
   
   module String = Graph.Imperative.Digraph.ConcreteLabeled(State)(StringTransition) *)


      


    
