(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let trash_dir = "trash/"
let ext = ".diag"

module type Arg =
sig
  module P : Sig.Pomset
  module T : Graph.Sig.ORDERED_TYPE_DFT with type t = P.t Automaton.edge Box.t
  module G : Graph.Sig.I with type V.t = Automaton.state Box.t and type E.t = Automaton.state Box.t * T.t * Automaton.state Box.t
  val declare_edge : 'a * T.t * 'a -> string
end

(* module P = Boxed_automaton.P
   module T = Boxed_automaton.T
   module G = Boxed_automaton.G 
   let declare_edge = Boxed_automaton.declare_edge *)

(* module P = Pomset_automaton.P
   module T = Pomset_automaton.T
   module G = Pomset_automaton.G
   let declare_edge = Pomset_automaton.declare_edge
*)

module Make (Arg : Arg) =
struct
  include Arg
    
  type state = 
      { 
	state : G.vertex;
	history : P.t;
	mutable start : bool;
	mutable final : bool;
      }
	
let is_start s = s.start
let is_final s = s.final
  
let create_state start final state history = 
  { start = start; final = final; state = state ; history = history }
    
module State =
struct
  type t = state 
  let compare s1 s2 = compare (Box.num s1.state) (Box.num s2.state)
  let equal s1 s2 = (Box.num s1.state) = (Box.num s2.state) && (P.equal s1.history s2.history)
  let hash s = 77*(Box.num s.state) + (P.hash s.history)
end
  
module U = Graph.Imperative.Digraph.ConcreteLabeled(State)(T) 
  
let choose l =
  if List.length l = 0 
  then raise (Invalid_argument "Unfold.choose")
  else List.nth l (Random.int (List.length l))
    
let one_step final u u_current label a_next =
  let history =
    P.compose u_current.history (Box.label label).Automaton.msc
  in
  let u_next = 
    create_state false (Automaton.is_final (Box.label a_next) && final history) a_next history 
  in
  let result = 
    if U.mem_vertex u u_next 
    then None
    else Some u_next
  in
    U.add_vertex u u_next;  
    U.add_edge_e u (u_current, Box.copy label, u_next);
    result
      
let one_step_final final u u_current label a_next =
  let u_next = 
    create_state false true a_next u_current.history 
  in
  let result = 
    if U.mem_vertex u u_next 
    then None
    else Some u_next
  in
    U.add_vertex u u_next;
    U.add_edge_e u (u_current, Box.copy label, u_next);
    result
      
      
let unfold (filter:State.t list -> State.t list) (final:P.t->bool) a =
  let u = U.create () 
  and empty = P.empty () 
  in
  let start_states =
    G.fold_vertex 
      (fun v accu -> 
	 if Automaton.is_start (Box.label v) 
	 then create_state true (Automaton.is_final (Box.label v) && final empty) v empty :: accu 
	 else accu) 
      a []
  in
  let fold_edges step u_current =
    G.fold_succ_e 
      (fun (a_current,e,a_next) accu -> 
	 match step final u u_current e a_next with
	   | None -> accu
	   | Some u_next -> u_next :: accu)
      a u_current.state []
  in
  let succ u_current =
    if is_final u_current then fold_edges one_step_final u_current else []
      @ fold_edges one_step u_current
  in 
  let rec iter iteration u_currents =
    if u_currents <> [] then
      let active_states = filter u_currents in
	(*Tools.print (Printf.sprintf "Step %i : %i active state(s)" iteration (List.length active_states));*)
	match active_states with
	  | [] -> ()
	  | l -> iter (iteration+1) (List.flatten (List.map succ l))
  in
    iter 0 start_states;
    u
      
let rec observe a n =
  Tools.print "A new observation begins ...";
  let diff history = n - (P.size history) in
  let u = unfold (function l -> [choose l]) (function v -> diff v <= 0) a in
  let all = U.fold_vertex (fun v accu -> v :: accu) u [] in 
  let final = List.filter (fun v -> diff v.history <= 0 && is_final v) all in
    if final <> []
    then (choose final).history
    else begin 
      Tools.print "No good candidate found ...";
      observe a n (*(choose all).history *)
    end

let diagnose a obs =
  let size_obs = P.size obs in
  let prefix = P.prefix_of obs in
  let u = unfold 
    (function l -> List.filter (function v -> prefix v.history) l) 
    (function v -> P.prefix_of obs v && size_obs = P.size v) 
    a 
  in
    u

module Remove = Automaton.Remove(U)
let remove_non_coaccessible_states = Remove.non_coaccessible_states is_final

(* dessin *)
module H = Hashtbl.Make(State)

let table = H.create 99

let compteur = ref 0

let read n =
  if not (H.mem table n) 
  then let i = !compteur in H.add table n i; incr compteur; i
  else H.find table n
    
let declare_node n =
  let history = n.history in
  let state = n.state in
  let num = string_of_int (read n) in
  let file_name =
    if history = P.empty () 
    then "\"\""
    else begin
      P.make_img ("history"^num) history;
      "<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"0\"><TR><TD>State "
      ^string_of_int (Box.num state)
      ^"</TD></TR><TR><TD><IMG SRC=\""
      ^Tools.files_dir^"history"^num^P.ext^".gif\"/></TD></TR></TABLE>>"
    end
  in
  let shape =
    if is_final n
    then "node [ shape=doublecircle label="^file_name^"];"
    else "node [ shape=circle width=.1 height=.1 label="^file_name^"];"
  in	
    shape ^ num ^ ";\n"
      
let string_of_edge (n1,e,n2) =
  "edge [dir=none]; "
  ^string_of_int (read n1)
  ^" -> "
  ^string_of_int (Box.num e)
  ^";\nedge [dir=normal]; "
  ^string_of_int (Box.num e)
  ^" -> "
  ^string_of_int (read n2)
  ^";\n"
    
let dot_of a =
  "digraph{\n"
  ^U.fold_edges_e (fun e s -> s ^ declare_edge e)  a ""
  ^U.fold_vertex  (fun v s -> s ^ declare_node v) a ""
  ^U.fold_edges_e (fun e s -> s ^ string_of_edge e) a ""
  ^"}\n"

let make_img file diag =
 let f = open_out (trash_dir ^ file ^ ext ^ ".dot")
  in
   Automaton.normalize_edges U.iter_edges_e ((U.nb_vertex diag)+1) diag;
   output_string f (dot_of diag);
   close_out f;
   Tools.print ("Creating " ^ files_dir ^ file ^ ext ^".gif");
   Tools.execute (Printf.sprintf "dot -Tgif -o %s%s%s.gif %s%s%s.dot" files_dir file ext trash_dir file ext)
end

module Normal = Make(Pomset_automaton)
module Boxed = Make(Boxed_automaton) 

include Boxed

