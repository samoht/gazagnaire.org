type token =
  | INT of (int)
  | STRING of (string)
  | CROC_O
  | CROC_F
  | TO
  | COLON
  | SEMICOLON
  | EOF
  | START
  | FINAL

open Parsing;;
# 6 "pa_parser.mly"
(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

  let parse_error s = (* Called by the parser function on error *)
    (* pour bien faire il faudrait un File %s, line %i: syntax error *)
    Printf.printf "hmsc : %s on characters %i-%i\n" s (symbol_start ()) (symbol_end ());
    flush stdout
# 39 "pa_parser.ml"
let yytransl_const = [|
  259 (* CROC_O *);
  260 (* CROC_F *);
  261 (* TO *);
  262 (* COLON *);
  263 (* SEMICOLON *);
    0 (* EOF *);
  264 (* START *);
  265 (* FINAL *);
    0|]

let yytransl_block = [|
  257 (* INT *);
  258 (* STRING *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\002\000\003\000\003\000\006\000\006\000\
\006\000\006\000\005\000\005\000\004\000\004\000\007\000\007\000\
\000\000"

let yylen = "\002\000\
\004\000\003\000\003\000\000\000\001\000\003\000\002\000\002\000\
\001\000\001\000\002\000\001\000\001\000\003\000\004\000\003\000\
\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\017\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\011\000\000\000\000\000\000\000\
\000\000\000\000\000\000\001\000\002\000\003\000\000\000\000\000\
\006\000\014\000\000\000\015\000\007\000\008\000"

let yydgoto = "\002\000\
\004\000\006\000\007\000\008\000\009\000\025\000\010\000"

let yysindex = "\003\000\
\010\255\000\000\013\255\000\000\000\255\011\255\009\255\012\255\
\014\255\015\255\016\255\017\255\000\000\022\000\013\255\013\255\
\250\254\021\255\023\255\000\000\000\000\000\000\018\255\020\255\
\000\000\000\000\024\255\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\022\255\000\000\001\255\000\000\000\000\000\000\
\025\255\026\255\001\255\000\000\000\000\000\000\022\255\022\255\
\000\000\000\000\003\255\000\000\000\000\000\000\027\255\028\255\
\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\252\255\000\000\000\000\251\255\000\000\006\000"

let yytablesize = 35
let yytable = "\013\000\
\011\000\023\000\024\000\001\000\012\000\013\000\012\000\012\000\
\016\000\016\000\021\000\022\000\003\000\005\000\014\000\015\000\
\011\000\019\000\016\000\017\000\018\000\020\000\026\000\027\000\
\028\000\004\000\029\000\030\000\012\000\000\000\000\000\005\000\
\013\000\009\000\010\000"

let yycheck = "\005\000\
\001\001\008\001\009\001\001\000\005\001\011\000\006\001\007\001\
\006\001\007\001\015\000\016\000\003\001\001\001\004\001\007\001\
\001\001\001\001\007\001\006\001\006\001\000\000\002\001\001\001\
\019\000\004\001\009\001\008\001\005\001\255\255\255\255\007\001\
\007\001\007\001\007\001"

let yynames_const = "\
  CROC_O\000\
  CROC_F\000\
  TO\000\
  COLON\000\
  SEMICOLON\000\
  EOF\000\
  START\000\
  FINAL\000\
  "

let yynames_block = "\
  INT\000\
  STRING\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'list) in
    Obj.repr(
# 37 "pa_parser.mly"
                       ( let v,e = _2 in (!v, e) )
# 128 "pa_parser.ml"
               : ((int, bool*bool) PMap.t) * ((int*string*int) Enum.t) ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'states) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list) in
    Obj.repr(
# 41 "pa_parser.mly"
                        ( 
    let vertices, (start,final) = _1 
    and v,e = _3 
    in 
    let aux i =
      v := PMap.add i (start,final) !v
    in
      List.iter aux vertices;
      (v, e) )
# 144 "pa_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'edges) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list) in
    Obj.repr(
# 50 "pa_parser.mly"
                          ( 
    let edges,label = _1
    and v,e = _3 
    in 
    let aux (v1,v2) =
      if not (PMap.mem v1 !v) then v := PMap.add v1 (false,false) !v;
      if not (PMap.mem v2 !v) then v := PMap.add v2 (false,false) !v;
      Enum.push e (v1,label,v2)
    in 
      List.iter aux edges;
      (v, e) )
# 162 "pa_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    Obj.repr(
# 61 "pa_parser.mly"
  ( let v = ref (PMap.empty) and e = Enum.empty () in (v, e) )
# 168 "pa_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'int_list) in
    Obj.repr(
# 65 "pa_parser.mly"
                        ( _1, (false,false) )
# 175 "pa_parser.ml"
               : 'states))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'int_list) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'special) in
    Obj.repr(
# 66 "pa_parser.mly"
                         ( _1, _3 )
# 183 "pa_parser.ml"
               : 'states))
; (fun __caml_parser_env ->
    Obj.repr(
# 70 "pa_parser.mly"
              ( (true, true) )
# 189 "pa_parser.ml"
               : 'special))
; (fun __caml_parser_env ->
    Obj.repr(
# 71 "pa_parser.mly"
              ( (true, true) )
# 195 "pa_parser.ml"
               : 'special))
; (fun __caml_parser_env ->
    Obj.repr(
# 72 "pa_parser.mly"
        ( (true, false) )
# 201 "pa_parser.ml"
               : 'special))
; (fun __caml_parser_env ->
    Obj.repr(
# 73 "pa_parser.mly"
        ( (false, true) )
# 207 "pa_parser.ml"
               : 'special))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : int) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'int_list) in
    Obj.repr(
# 77 "pa_parser.mly"
               ( _1 :: _2 )
# 215 "pa_parser.ml"
               : 'int_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 78 "pa_parser.mly"
               ( [_1])
# 222 "pa_parser.ml"
               : 'int_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'links) in
    Obj.repr(
# 82 "pa_parser.mly"
                     ( _1, "" )
# 229 "pa_parser.ml"
               : 'edges))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'links) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 83 "pa_parser.mly"
                     ( _1, _3 )
# 237 "pa_parser.ml"
               : 'edges))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : int) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'links) in
    Obj.repr(
# 87 "pa_parser.mly"
                   ( (_1,_3) :: _4 )
# 246 "pa_parser.ml"
               : 'links))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 88 "pa_parser.mly"
                   ( [_1,_3] )
# 254 "pa_parser.ml"
               : 'links))
(* Entry input *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let input (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : ((int, bool*bool) PMap.t) * ((int*string*int) Enum.t) )
