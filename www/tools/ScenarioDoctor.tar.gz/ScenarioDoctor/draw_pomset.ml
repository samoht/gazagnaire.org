(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)


let files_dir = Pomset.files_dir
let trash_dir = Pomset.trash_dir
let ext = Pomset.ext

(***dessin***)
let action_name (v:Pomset.G.vertex) = Bmsc.action_name (Box.label v) 
let instance (v:Pomset.G.vertex) = Bmsc.instance (Box.label v) 
let associated_instance (v:Pomset.G.vertex) = Bmsc.associated_instance (Box.label v) 
let is_intl (v:Pomset.G.vertex) = Bmsc.is_intl (Box.label v) 
let is_send (v:Pomset.G.vertex) = Bmsc.is_send (Box.label v) 
let is_recv (v:Pomset.G.vertex) = Bmsc.is_recv (Box.label v) 
let pp v = Bmsc.pp (Box.label v)
let same_message v1 v2 = Bmsc.same_message (Box.label v1) (Box.label v2)

let list_of_instances a =
  let classes = Classes.classes a in
    List.map instance (Classes.I.to_list classes) 


module Bmsc =
struct
  module L = Tools.Level(Pomset.G)
    
  let string_of_alone e name =
    "\\gate*[c]{"^name^"}{"^string_of_int (instance e)^"}\n"
      
  let string_of_futur pomset level v1 =
    let aux v2 =
      if instance v1 = instance v2 || same_message v1 v2
      then ""
      else "\\order{"^string_of_int (instance v1)^"}{"^string_of_int(instance v2)^"}["^string_of_int ((level v2) - (level v1))^"]\n"
    in
      List.fold_left (^) "" (List.map aux (Pomset.G.succ pomset v1))
	
  let string_of_intl pomset level e =
    string_of_alone e (action_name e)
    ^string_of_futur pomset level e
      
  let string_of_recv pomset level e =
    let s =
      if List.filter (function e2 -> action_name e2 = action_name e && is_send e2) (Pomset.G.pred pomset e) = []
      then 	(* si il est tout seul on trouve un message *)
	(*string_of_alone e ("?"^action_name e)*)
	"\\found"
 	^"["^ (if instance e < associated_instance e then "l" else "r") ^"]"
	^"{}{"^ action_name e ^"}"
	^"{"^ string_of_int (instance e) ^"}\n"
      else ""  (* si il est associe a un envoi de message, on ne dessine rien, on s'en chargera quand
		  on traitera l'envoi associe *)
    in
      s^string_of_futur pomset level e
	
  (* p est le pomset, h est la fonction de hauteur *)
  let string_of_send pomset level e1 =  
    let aux e2 = 
      if same_message e1 e2 then 
	"\\mess{"^action_name e1 ^"}"
	^"{"^ string_of_int (instance e1) ^"}"
	^"{"^ string_of_int (instance e2) ^"}"
	^"["^ string_of_int ((level e2) - (level e1)) ^"]\n"
      else ""
    in
    let s = List.fold_left (^) "" (List.map aux (Pomset.G.succ pomset e1)) in
      (if s = "" 
       then (* si il est tout seul, on a perdu un message *)
	 (* string_of_alone e1 ("!"^action_name e1) *)
	 "\\lost"
	 ^"["^ (if instance e1 > associated_instance e1 then "l" else "r") ^"]"
	 ^"{}{"^ action_name e1 ^"}"
	 ^"{"^ string_of_int (instance e1) ^"}\n"

       else s)
      ^string_of_futur pomset level e1
	
  let string_of_level pomset level level_list = 
    List.fold_left (^) "" (List.map (string_of_send pomset level) (List.filter is_send level_list))
    ^List.fold_left (^) "" (List.map (string_of_intl pomset level) (List.filter is_intl level_list))
    ^List.fold_left (^) "" (List.map (string_of_recv pomset level) (List.filter is_recv level_list))
    ^"\\nextlevel\n"
      
  let string_of_graph pomset =
    let level = L.level pomset in
    let levels = L.decomposition level pomset in   
      List.fold_left (^) "" (List.map (string_of_level pomset level) levels)
	
  let string_of_instances e =
    let aux i =
      "\\declinst{"^string_of_int i^"}{}"
      ^"{Process"^string_of_int i^"}\n"
    in
    let s = ref "" in
      List.iter (function i -> s := !s^aux i) e;
      !s
	
  let string_of_bmsc name b =
    "\\begin{msc}{"^name^"}\n"
    ^string_of_instances (List.sort compare (list_of_instances b))
    ^string_of_graph b 
    ^"\\end{msc}\n"
      
  let to_latex file b =
    "\\documentclass{article}\n"
    ^"\\pagestyle{empty}\n"
    ^"\\usepackage[active, tightpage]{preview}\n"
    ^"\\usepackage{msc}\n"
    ^"\\drawframe{no}"    
    ^"\\begin{document}\n"
    ^"\\begin{preview}\n"
    ^(string_of_bmsc file b)
    ^"\\end{preview}"
      
  (* TODO : gerer quand ca depasse 1 page *)
  let to_ps file pomset =
    let f = open_out (trash_dir^file^ext^".tex") 
    in
      Linearize.linearize pomset;
      output_string f (to_latex file pomset); 
      close_out f;
      Tools.execute ("latex -interaction=nonstopmode -output-directory="^trash_dir^" "^trash_dir^file^ext^".tex >> "^trash_dir^"latex.out");
      Tools.execute ("dvips -o "^trash_dir^file^ext^".ps "^trash_dir^file^ext^".dvi")
	
  let make_img file pomset =
    Tools.print ("Creating "^files_dir^file^ext^".png");
    to_ps file pomset;
    Tools.execute ("gs -dBATCH -sDEVICE=png16 -dTextAlphaBits=4 -r300 -dGraphicsAlphaBits=4 -dSAFER -q -dNOPAUSE -sOutputFile="^files_dir^file^ext^".png "^trash_dir^file^ext^".ps");
    Tools.execute ("convert "^files_dir^file^ext^".png "^files_dir^file^ext^".gif")
end

module Graph =
struct
  let string_of_instance a i =
    "subgraph cluster_"^string_of_int i^" {\n"
    ^"style=filled;\ncolor=lightgrey;\nnode [style=filled, color=white];\n"
    ^Pomset.G.fold_vertex (fun v accu -> accu ^ if instance v = i then string_of_int (Box.num v) ^ "; " else "") a ""
    ^"label = \"process #"^string_of_int i^"\";\n}\n"
      
  let string_of_node n =
    string_of_int (Box.num n) ^ " [label=\"" ^ pp n ^ "\"];\n"

  let string_of_edge n1 n2 =
    string_of_int (Box.num n1) ^ " -> " ^ string_of_int (Box.num n2) ^ ";\n"

  let to_dot a =
    "digraph G {\n"
    ^List.fold_left (fun accu i -> accu ^ string_of_instance a i) "" (List.sort compare (list_of_instances a))
    ^Pomset.G.fold_vertex (fun n accu -> accu ^ string_of_node n) a ""
    ^Pomset.G.fold_edges (fun n1 n2  accu -> accu ^ string_of_edge n1 n2) a ""
    ^"}\n"

  let make_png file pomset =
    let f = open_out (trash_dir^file^ext^".dot") 
    in
      output_string f (to_dot pomset); 
      close_out f;
      Tools.execute ("dot "^trash_dir^file^ext^".dot -Tpng -o "^files_dir^file^ext^".png")
end


let make_img = Bmsc.make_img 
