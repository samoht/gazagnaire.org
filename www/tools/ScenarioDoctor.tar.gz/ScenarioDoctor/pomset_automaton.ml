(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let trash_dir = "trash/"
let ext = ".hmsc"

module P = 
struct
  type t = Pomset.t
  type elt = Pomset.elt
  let from_file = Pomset.from_file
  let to_file = Pomset.to_file
  let union = Pomset.union
  let compose = Pomset.compose
  let empty = Pomset.empty
  let project = Pomset.project
  let size = Pomset.size
  let ext = Pomset.ext
  let equal = Isomorphism.equal
  let prefix_of = Isomorphism.prefix_of
  let hash = Isomorphism.hash
  let make_img = Draw_pomset.make_img
end

include Automaton 

module T =
struct
  type t = Pomset.t edge Box.t
  let compare e1 e2 = compare (Box.num e1) (Box.num e2)
  let default = Box.create { name = "" ; msc = Pomset.empty () }
end

let create_edge name msc =
  Box.create { name = name; msc = msc }

let compose e1 e2 = 
  { 
    name = e1.name ^ "." ^ e2.name ;
    msc = Pomset.compose e1.msc e2.msc
  }

module G = Graph.Imperative.Digraph.ConcreteLabeled(Automaton.State)(T) 

let from_file name =
  let in_channel = open_in (files_dir ^ name ^ ext) in
  let lexbuf = Lexing.from_channel in_channel in
    let vertices, edges = Pa_parser.input Pa_lexer.token lexbuf in
    let v = PMap.mapi (fun i (s,f) -> Box.new_box i (Automaton.create_state s f)) vertices in
    let e = Enum.map (function (i,e,j) -> PMap.find i v, create_edge e (Pomset.from_file e), PMap.find j v) edges in
    let p = G.create () in
      close_in in_channel;
      PMap.iter (fun i v -> G.add_vertex p v) v;
      Enum.iter (fun (i,le,j) -> G.add_edge_e p (i,le,j)) e;
      p

let edge_table = Hashtbl.create 99

let declare_edge (_,edge,_) =
  let num = string_of_int (Box.num edge) in
  let label = Box.label edge in
  let dot_label =
    if label.name <> "" 
    (* then "[label=\""^label.name^"\"]" *)
    then begin
      if not (Hashtbl.mem edge_table label.name) 
      then begin
	P.make_img label.name label.msc;
	Hashtbl.add edge_table label.name true;
      end;
      "[ label=<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"0\"><TR><TD><IMG SRC=\""
      ^Pomset.files_dir^label.name^Pomset.ext
      ^".gif\"/></TD></TR></TABLE>> style=\"setlinewidth(2),rounded\" ]" end
    else ""
  in
  let shape = 
    if label.name = "" 
    then "node [ shape=rect width=0 height=0 label=\"\" ];"
    else "node [ shape=rect ];"
  in
    shape ^ num ^ dot_label ^ ";\n"
      
let declare_node n =
  let num = string_of_int (Box.num n) in
  let label = Box.label n in
  let shape =
    if Automaton.is_start label && Automaton.is_final label  
    then "node [ style=\"setlinewidth(2)\" shape=doublecircle width=1 height=1 label=\"\" ];"
    else if Automaton.is_start label 
    then "node [ style=\"setlinewidth(2)\" shape=invtriangle width=1 height=1 label=\"\" ];"
    else if Automaton.is_final label
    then "node [ style=\"setlinewidth(2)\" shape=triangle width=1 height=1 label=\"\" ];"
    else "node [ style=\"setlinewidth(2)\" shape=circle width=1 height=1 label=\"\" ];"
  in	
    shape ^ num ^ ";\n"
      
let string_of_edge (n1,e,n2) =
  if (Box.label e).name <> "" then 
    "edge [ dir=none style=\"setlinewidth(2)\" ]; "
    ^string_of_int (Box.num n1)
    ^" -> "
    ^string_of_int (Box.num e)
    ^";\nedge [ dir=normal arrowsize=2 style=\"setlinewidth(2)\" ]; "
    ^string_of_int (Box.num e)
    ^" -> "
    ^string_of_int (Box.num n2)
    ^";\n"
  else
    "edge [ dir=normal style=\"setlinewidth(2)\" ]; "
    ^string_of_int (Box.num n1)
    ^" -> "
    ^string_of_int (Box.num n2)
    ^";\n" 

      
let dot_of a =
  "digraph{\n"
  ^G.fold_edges_e (fun e s -> s ^ declare_edge e)  a ""
  ^G.fold_vertex  (fun v s -> s ^ declare_node v) a ""
  ^G.fold_edges_e (fun e s -> s ^ string_of_edge e) a ""
  ^"}\n"
    
let make_img file hmsc =
  let f = open_out (trash_dir ^ file ^ ext ^ ".dot")
  in
    output_string f (dot_of hmsc);
    close_out f;
    Tools.print ("Creating " ^ files_dir ^ file ^ ext ^".gif");
    Tools.execute (Printf.sprintf "dot -Tgif -o %s%s%s.gif %s%s%s.dot" files_dir file ext trash_dir file ext)




