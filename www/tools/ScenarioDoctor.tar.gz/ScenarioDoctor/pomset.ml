(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let trash_dir = "trash/"
let ext = ".msc"

module Event =
struct
  type t = Bmsc.t Box.t
  let compare e1 e2 = compare (Box.num e1) (Box.num e2)
  let equal e1 e2 = (Box.num e1) = (Box.num e2)
  let hash e1 = Hashtbl.hash (Box.num e1)
end

module G = Graph.Imperative.Digraph.Concrete(Event)

type t = G.t
type elt = G.V.t
let empty () = G.create ()

let from_file name =
  if name <> "" then begin
    let in_channel = open_in (files_dir ^ name ^ ext) in
    let lexbuf = Lexing.from_channel in_channel in
    let vertices, edges = Bmsc_parser.input Bmsc_lexer.token lexbuf in
    let v = PMap.map (fun l -> Box.create l) vertices in
    let e = Enum.map (function (i,j) -> PMap.find i v, PMap.find j v) edges in
    let p = G.create () in
      close_in in_channel;
      PMap.iter (fun i v -> G.add_vertex p v) v;
      Enum.iter (fun (i,j) -> G.add_edge p i j) e;
      p
  end
  else empty ()

let to_string g =
  let num_vertex v = 
    string_of_int (Box.num v) 
  in
  let label_vertex v =
    Bmsc.to_string (Box.label v)
  in
    "{\n"
    ^G.fold_vertex (fun v accu -> accu ^ num_vertex v ^ " : " ^ label_vertex v ^ ";\n") g ""
    ^G.fold_edges_e (fun (v1,v2) accu -> accu ^ num_vertex v1 ^ " -> " ^ num_vertex v2 ^ ";\n") g ""
    ^"}"

let to_file file g = 
  let s = to_string g in
  let f = open_out (files_dir^file^ext) in
    output_string f s;
    close_out f


(* comment ca a pu marcher ??? *)
let union g1 g2 =
  let g3 = G.create () in
  let vertex = Hashtbl.create 99 in
  let add_vertex1 v =
    G.add_vertex g3 v
  in
  let add_vertex2 v =
    let v2 = Box.copy v in
      Hashtbl.add vertex v v2;
      G.add_vertex g3 v2
  in
  let add_edge v1 v2 =
    G.add_edge g3 (Hashtbl.find vertex v1) (Hashtbl.find vertex v2);
  in
    G.iter_vertex add_vertex1 g1;
    G.iter_vertex add_vertex2 g2;
    G.iter_edges (G.add_edge g3) g1;
    G.iter_edges add_edge g2;
    (Hashtbl.find vertex, g3)



module Transitive = Tools.Transitive(G)

let compose_with_assoc p1 p2 = 
  let assoc, p3 = union p1 p2 in
    G.iter_vertex 
      (function v1 -> G.iter_vertex 
	 (function v2 -> 
	    if !Composition.predicate (Box.label v1) (Box.label v2) 
	    then G.add_edge p3 v1 (assoc v2)) 
	 p2)
      p1;
    assoc, Transitive.reduction p3

let compose p1 p2 = snd (compose_with_assoc p1 p2)

let size = G.nb_vertex

module P = Tools.Project(G)
let project = P.project



