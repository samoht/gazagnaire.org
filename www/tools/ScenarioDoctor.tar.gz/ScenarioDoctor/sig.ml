(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

module type Pomset =
sig
  type t
  type elt
  val from_file : string -> t
  val to_file : string -> t -> unit
  val compose : t -> t -> t
  val empty : unit -> t
  val equal : t -> t -> bool
  val prefix_of : t -> t -> bool
  val hash : t -> int
  val project : (elt -> bool) -> t -> t
  val size : t -> int
  val make_img : string -> t -> unit
  val ext : string
end
