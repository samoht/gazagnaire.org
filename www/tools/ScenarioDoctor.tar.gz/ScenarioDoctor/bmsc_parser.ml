type token =
  | INT of (int)
  | STRING of (string)
  | CROC_O
  | CROC_F
  | TO
  | COLON
  | SEMICOLON
  | EOF
  | SEND
  | RECV
  | INTL

open Parsing;;
# 6 "bmsc_parser.mly"
(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

  let parse_error s = (* Called by the parser function on error *)
    (* pour bien faire il faudrait un File %s, line %i: syntax error *)
    Printf.printf "msc : %s on characters %i-%i\n" s (symbol_start ()) (symbol_end ());
    flush stdout
# 40 "bmsc_parser.ml"
let yytransl_const = [|
  259 (* CROC_O *);
  260 (* CROC_F *);
  261 (* TO *);
  262 (* COLON *);
  263 (* SEMICOLON *);
    0 (* EOF *);
  264 (* SEND *);
  265 (* RECV *);
  266 (* INTL *);
    0|]

let yytransl_block = [|
  257 (* INT *);
  258 (* STRING *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\002\000\003\000\006\000\006\000\006\000\
\005\000\005\000\004\000\000\000"

let yylen = "\002\000\
\004\000\003\000\003\000\000\000\003\000\004\000\004\000\003\000\
\002\000\001\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\012\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\009\000\000\000\000\000\000\000\000\000\
\011\000\001\000\002\000\003\000\000\000\000\000\000\000\005\000\
\000\000\000\000\000\000\000\000\000\000\008\000\006\000\007\000"

let yydgoto = "\002\000\
\004\000\006\000\007\000\008\000\009\000\024\000"

let yysindex = "\009\000\
\254\254\000\000\010\255\000\000\001\255\008\255\006\255\007\255\
\009\255\015\255\016\255\000\000\018\000\010\255\010\255\255\254\
\000\000\000\000\000\000\000\000\018\255\019\255\020\255\000\000\
\021\255\022\255\023\255\025\255\026\255\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\024\255\000\000\027\255\000\000\000\000\000\000\
\000\000\027\255\000\000\000\000\000\000\024\255\024\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\245\255\000\000\000\000\251\255\000\000"

let yytablesize = 33
let yytable = "\012\000\
\003\000\010\000\019\000\020\000\012\000\011\000\021\000\022\000\
\023\000\001\000\005\000\013\000\014\000\015\000\016\000\010\000\
\017\000\018\000\025\000\026\000\027\000\000\000\028\000\029\000\
\030\000\031\000\032\000\004\000\000\000\000\000\000\000\000\000\
\010\000"

let yycheck = "\005\000\
\003\001\001\001\014\000\015\000\010\000\005\001\008\001\009\001\
\010\001\001\000\001\001\004\001\007\001\007\001\006\001\001\001\
\001\001\000\000\001\001\001\001\001\001\255\255\002\001\002\001\
\002\001\001\001\001\001\004\001\255\255\255\255\255\255\255\255\
\006\001"

let yynames_const = "\
  CROC_O\000\
  CROC_F\000\
  TO\000\
  COLON\000\
  SEMICOLON\000\
  EOF\000\
  SEND\000\
  RECV\000\
  INTL\000\
  "

let yynames_block = "\
  INT\000\
  STRING\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'list) in
    Obj.repr(
# 37 "bmsc_parser.mly"
                       ( let v,e = _2 in (!v, e) )
# 129 "bmsc_parser.ml"
               : ((int, Bmsc.t) PMap.t) * ((int*int) Enum.t) ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'event) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list) in
    Obj.repr(
# 41 "bmsc_parser.mly"
                       ( 
    let v,e = _3 in 
    let vertices,label = _1 in 
    let aux i =
      v := PMap.add i label !v
    in
      List.iter aux vertices;
      (v, e) )
# 144 "bmsc_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'link) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list) in
    Obj.repr(
# 49 "bmsc_parser.mly"
                         ( 
    let v1,v2 = _1
    and v,e = _3 
    in 
      (*      if not (PMap.mem v1 !v) then raise Parse_error;
	      if not (PMap.mem v2 !v) then raise Parse_error; *)
      Enum.push e (v1,v2);
      (v, e) )
# 159 "bmsc_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    Obj.repr(
# 57 "bmsc_parser.mly"
  ( let v = ref (PMap.empty) and e = Enum.empty () in (v, e) )
# 165 "bmsc_parser.ml"
               : 'list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'int_list) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'label) in
    Obj.repr(
# 61 "bmsc_parser.mly"
                       ( (_1:int list), (_3:Bmsc.t) )
# 173 "bmsc_parser.ml"
               : 'event))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 65 "bmsc_parser.mly"
                      ( Bmsc.Send (_2, _3, _4) )
# 182 "bmsc_parser.ml"
               : 'label))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 66 "bmsc_parser.mly"
                      ( Bmsc.Recv (_2, _3, _4) )
# 191 "bmsc_parser.ml"
               : 'label))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 67 "bmsc_parser.mly"
                  ( Bmsc.Intl (_2, _3) )
# 199 "bmsc_parser.ml"
               : 'label))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : int) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'int_list) in
    Obj.repr(
# 71 "bmsc_parser.mly"
               ( _1 :: _2 )
# 207 "bmsc_parser.ml"
               : 'int_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 72 "bmsc_parser.mly"
               ( [_1])
# 214 "bmsc_parser.ml"
               : 'int_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 76 "bmsc_parser.mly"
             ( (_1,_3) )
# 222 "bmsc_parser.ml"
               : 'link))
(* Entry input *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let input (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : ((int, Bmsc.t) PMap.t) * ((int*int) Enum.t) )
