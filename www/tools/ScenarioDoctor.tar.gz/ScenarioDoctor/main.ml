(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let _ = Random.self_init ()

(* variables qui configurent le programme *)
type action =
  | Niet
  | Draw
  | Observe of int
  | Diagnose

let action = ref Niet
let max_events = ref 10
let bmsc = ref ""
let hmsc = ref ""
let obs = ref ""
let verbose = ref false  
let causal = ref ""

let observe k = 
  action := Observe k

let diagnose () = 
  action := Diagnose

let draw () = 
  action := Draw



let _ = 
  Arg.parse 
    (Arg.align [ "-v", Arg.Set verbose, " verbose mode";
		 
		 "-observe", Arg.Int observe, " <int> Build an observation of size <int>";
		 
		 "-diagnose", Arg.Unit diagnose, " Perform diagnosis";
		 
		 "-draw", Arg.Unit draw, " Draw results";
		 
		 "-b", Arg.Set_string bmsc, 
		 " <string> read/write/use the bMSC '"^Pomset.files_dir^"<string>.bmsc'"; 
		 
		 "-h", Arg.Set_string hmsc, 
		 " <string> use the HMSC specification '"^Pomset_automaton.files_dir^"<string>.hmsc'"; 
		 
		 "-o", Arg.Set_string obs, 
		 " <string> set the observable alphabet to '"^Observation.files_dir^"/<string>.obs'"; 

		 "-causal", Arg.Set_string causal, 
		 " use causal concatenation. Dependency relation is read in '"^Composition.files_dir^"<string>.dep'";
	       ])
    (function s -> raise (Arg.Bad s))
    "use the following option(s) :";
  
  match !action with
    | Niet -> raise (Arg.Bad "main action is missing")
    | Observe k -> 
	if (!hmsc = "" || !bmsc = "") then raise (Arg.Bad "You must use -o, -b and -h options");
	if (!obs = "")
	then Tools.print "Every letters are observable"
	else Tools.print ("Reading observable alphabet in "^Tools.files_dir ^ !obs ^ Observation.ext); 
	if (!causal = "")
	then Tools.print "We use weak concatenation"
	else begin
	  Tools.print "We use causal concatenation";
	  Composition.read_dependencies !causal;
	  Composition.print_dependencies ();
	end;
	(* on charge l'automate *)
	let a = Pomset_automaton.from_file !hmsc in
	  
	(* on le deplie pour construire l'observation *)
	let exec = Unfold.Normal.observe a k in
	
	(* si on doit projeter, on projette *)
	let obs =
	  if !obs = "" then exec
	  else Pomset.project (Observation.parse !obs) exec in

	  (* on enregistre l'observation et on l'affiche *)
	  Draw_pomset.make_img !bmsc obs;
	  Pomset.to_file !bmsc obs
	    
    | Draw ->
	if !bmsc <> "" then Draw_pomset.make_img !bmsc (Pomset.from_file !bmsc);
	if !hmsc <> "" then Pomset_automaton.make_img !hmsc (Pomset_automaton.from_file !hmsc)
    
    | Diagnose ->
	(* if (!hmsc = "" || !bmsc = "") then raise (Arg.Bad "You must use -o, -b and -h options");
	   if (!obs = "") 
	   then Tools.print "Warning : every letters are observable"
	   else Tools.print ("Reading observable alphabet in "^Tools.files_dir ^ !obs ^ Observation.ext);
	   let is_proj = if !obs = "" then function _ -> true else Observation.parse !obs in
	   let obs = Pomset.from_file !bmsc in
	   let a = Pomset_automaton.from_file !hmsc in
	   let bobs = Boxed_pomset.box (Boxed_automaton.classes a) obs in
	   let ba = Boxed_automaton.of_pomset_automaton a in
	   let pba = Boxed_automaton.project is_proj ba in
	   let diag = Unfold.diagnose pba bobs in
	   let diag_simple = Unfold.remove_non_coaccessible_states diag in 
	   Tools.print (Printf.sprintf "Creating %i gif files ... (it can take a while)" ((Unfold.U.nb_vertex diag_simple)+1)); 
	   Unfold.P.make_img "observation" bobs;
	   Unfold.make_img !hmsc diag_simple  *)
	Tools.print "Pas encore debugge"





