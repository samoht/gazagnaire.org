(* Copyright 2006 Thomas Gazagnaire <thomas.gazagnaire@gmail.com>

 This file is part of ScenarioDoctor.

    ScenarioDoctor is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    ScenarioDoctor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ScenarioDoctor; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *)

let files_dir = "files/"
let extension = ".dep"

let bmsc e1 e2 =
  (Bmsc.instance e1) = (Bmsc.instance e2)

let predicate = ref bmsc



let depend_list = ref []

let read_dependencies file =
  let in_channel = open_in (files_dir ^ file ^ extension) in
  let lexbuf = Lexing.from_channel in_channel in
  let d = Depend_parser.input Depend_lexer.token lexbuf in
    close_in in_channel;
    
    (* TODO : on rajoute : pas d'auto-concurrence ... est-ce que c'est necessaire je sais pas ... *)
    let are_dependent e1 e2 =
      e1 = e2 || List.mem (e1,e2) d || List.mem (e2,e1) d 
    in

      depend_list := d;
      predicate := are_dependent
	

let print_dependencies () =
  let s = 
    "D = { "
    ^List.fold_left (fun accu (e1,e2) -> accu ^"( "^ Bmsc.pp e1 ^", "^ Bmsc.pp e2^" ) ") "" !depend_list 
    ^" }"
  in
    Tools.print s
   

